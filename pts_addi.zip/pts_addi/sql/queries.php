<?php
/**
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * @author    Addi <soporte@addi.com>
 * @copyright 2024 Addi, All rights reserved.
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *
 * @category  PrestaShop
 * @category  Module
 */

return [
    'install' => [
        'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'addi_order` (
            `id_order` int(11) NOT NULL AUTO_INCREMENT,
            `id_order_addi` varchar(255) NOT NULL,
            `id_application` varchar(255) NOT NULL,
            `amount` decimal(20,6) NOT NULL,
            `id_currency` int(11) NOT NULL,
            `status`int(11) NOT NULL,
            `date_add` datetime NOT NULL,
            PRIMARY KEY (`id_order`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;',
    ],
    'uninstall' => [
        'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . '_addi_order`;',
    ],
    'shop' => [],
];
