<?php
require_once __DIR__ . '/vendor/autoload.php';

if (!defined('_PS_VERSION_')) {
    exit;
}

class Pts_Addi extends PaymentModule
{
    const NAME = 'pts_addi';
    const VERSION = '5.0.4';
    const PREFIX = 'ADDI';
    const TAB_NAME = 'PTS Addi';

    const ADDI_ALLOWED_COUNTRIES = ['CO'];
    const ADDI_ALLOWED_CURRENCIES = ['COP'];

    public $authorAddress;
    private $moduleQueries;

    public static $moduleConfigList = [
        'ADDI_VERSION' => ['options' => ['default_value' => self::VERSION]],

        'ADDI_OVERRIDE_JS' => ['options' => ['default_value' => '']],
        'ADDI_OVERRIDE_CSS' => ['options' => ['default_value' => '']],

        'ADDI_WIDGET_JS_SRC' => ['options' => ['default_value' => 'https://s3.amazonaws.com/widgets.addi.com/bundle.min.js']],

        'ADDI_ENABLE_DEBUG' => ['options' => ['default_value' => 0, 'is_bool' => true]],
        'ADDI_IP_DEBUG' => ['options' => ['default_value' => '']],
        'ADDI_CALLBACK_USER' => ['options' => ['default_value' => '']],
        'ADDI_CALLBACK_PASSWORD' => ['options' => ['default_value' => '']],

        'ADDI_ENABLE_SANDBOX' => ['options' => ['default_value' => 1, 'is_bool' => true]],
        'ADDI_ALLY_SLUG' => ['options' => ['default_value' => '']],
        'ADDI_CLIENT_ID' => ['options' => ['default_value' => '']],
        'ADDI_CLIENT_SECRET' => ['options' => ['default_value' => '']],

        'ADDI_TOKEN' => ['options' => ['default_value' => '']],
    ];

    public static $moduleHookList = [
        'displayHeader',
        'displayProductAdditionalInfo',
        'paymentOptions',
    ];

    public static $moduleTabList = [
        'AdminTranslation',
        'AdminCodeEditor',
        'AdminModule',
        'AdminOptionForm',
        // tab list module
        'AdminGeneral',
        'AdminCredential',
    ];

    public function __construct()
    {
        $this->name = 'pts_addi';
        $this->tab = 'payments_gateways';
        $this->version = '5.0.4';
        $this->author = 'Addi';
        $this->controllers = ['callback', 'orderfailed', 'validation', 'redirect', 'statusorder', 'validation'];

        $this->module_key = '';
        $this->authorAddress = '';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = 'PTS Addi';
        $this->description = $this->l('Integration of Addi Colombia with PrestaShop');
        $this->confirmUninstall = $this->l('Are you sure you want uninstall?');
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];

        if (!version_compare(_PS_VERSION_, '1.7.0.0', '>=') && _PS_MODE_DEV_) {
            Symfony\Component\Debug\Debug::enable();
        }
    }

    public function getModuleQueries()
    {
        $moduleQueries = require_once _PS_MODULE_DIR_ . $this->name . '/sql/queries.php';
        if ($moduleQueries !== true) {
            $this->moduleQueries = $moduleQueries;
        }

        return $this->moduleQueries;
    }

    public function install()
    {
        if (
            !parent::install() ||
            !\Pts_Addi\PTSService::get('pts_addi.install.installer')->install() ||
            !$this->addCountriesConfiguration() ||
            !$this->addCallbackCredentials() ||
            !$this->createOrderStates()
        ) {
            return false;
        }

        return true;
    }

    private function addCountriesConfiguration()
    {
        $countryId = (int) Country::getByIso('CO');
        $country = new Country($countryId);
        if (!Validate::isLoadedObject($country)) {
            throw new \Pts_Addi\Exception\PTSException("The country 'Colombia' data didn\'t load correctly");
        }

        $country->need_identification_number = true;
        $country->save();

        $addressFormat = AddressFormat::getAddressCountryFormat($countryId);
        $originalFormat = $addressFormat;

        if (!strpos($addressFormat, 'dni')) {
            $addressFormat .= "\n" . 'dni';
        }

        if (!strpos($addressFormat, 'phone_mobile')) {
            $addressFormat .= "\n" . 'phone_mobile';
        }

        if ($addressFormat !== $originalFormat) {
            $sql = 'UPDATE `' . _DB_PREFIX_ . 'address_format`
            SET `format` = "' . pSQL($addressFormat) .
            '" WHERE `id_country` = ' . $countryId;

            $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
            $db->execute(trim($sql));
        }

        if (version_compare(_PS_VERSION_, '1.7.3', '>=')) {
            $customerAddress = new CustomerAddress();
            $requiredFields = $customerAddress->getFieldsRequiredDB();
            if (!in_array('phone_mobile', $requiredFields)) {
                $customerAddress->addFieldsRequiredDatabase(['phone_mobile']);
            }
        } else {
            $address = new Address();
            $requiredFields = $address->getFieldsRequiredDB();
            if (!in_array('phone_mobile', $requiredFields)) {
                $address->addFieldsRequiredDatabase(['phone_mobile']);
            }
        }

        return true;
    }

    private function addCallbackCredentials()
    {
        $callBackUser = 'AddiCommerce';
        $callBackPassword = 'AddiU91lasQWE877';//Tools::passwdGen(16);

        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');
        $configurationService->set('ADDI_CALLBACK_USER', $callBackUser);
        $configurationService->set('ADDI_CALLBACK_PASSWORD', $callBackPassword);

        return true;
    }

    private function createOrderStates()
    {
        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');

        $addiOrderStatus = [
            'PTS_ADDI_APPROVED' => [
                'name' => [],
                'invoice' => true,
                'send_email' => false,
                'logable' => true,
                'color' => '#2ecc71',
                'hidden' => false,
                'delivery' => false,
            ],
            'PTS_ADDI_PENDING' => [
                'name' => [],
                'invoice' => false,
                'send_email' => false,
                'logable' => false,
                'color' => '#f1c40f',
                'hidden' => false,
                'delivery' => false,
            ],
            'PTS_ADDI_REJECTED' => [
                'name' => [],
                'invoice' => false,
                'send_email' => false,
                'logable' => false,
                'color' => '#e74c3c',
                'hidden' => false,
                'delivery' => false,
            ],
            'PTS_ADDI_ABANDONED' => [
                'name' => [],
                'invoice' => false,
                'send_email' => false,
                'logable' => false,
                'color' => '#e74c3c',
                'hidden' => false,
                'delivery' => false,
            ],
            'PTS_ADDI_DECLINED' => [
                'name' => [],
                'invoice' => false,
                'send_email' => false,
                'logable' => false,
                'color' => '#e74c3c',
                'hidden' => false,
                'delivery' => false,
            ],
            'PTS_ADDI_INTERNAL_ERROR' => [
                'name' => [],
                'invoice' => false,
                'send_email' => false,
                'logable' => false,
                'color' => '#e74c3c',
                'hidden' => false,
                'delivery' => false,
            ],
        ];

        $languages = Language::getLanguages();
        foreach ($languages as $lang) {
            if ($lang['iso_code'] === 'es' || $lang['iso_code'] === 'cb') {
                $addiOrderStatus['PTS_ADDI_APPROVED']['name'][$lang['id_lang']] = 'Aprobado - Addi';
                $addiOrderStatus['PTS_ADDI_PENDING']['name'][$lang['id_lang']] = 'Pendiente - Addi';
                $addiOrderStatus['PTS_ADDI_REJECTED']['name'][$lang['id_lang']] = 'Rechazado - Addi';
                $addiOrderStatus['PTS_ADDI_ABANDONED']['name'][$lang['id_lang']] = 'Abandonado - Addi';
                $addiOrderStatus['PTS_ADDI_DECLINED']['name'][$lang['id_lang']] = 'Declinado - Addi';
                $addiOrderStatus['PTS_ADDI_INTERNAL_ERROR']['name'][$lang['id_lang']] = 'Error interno - Addi';
            } else {
                $addiOrderStatus['PTS_ADDI_APPROVED']['name'][$lang['id_lang']] = 'Approved - Addi';
                $addiOrderStatus['PTS_ADDI_PENDING']['name'][$lang['id_lang']] = 'Pending - Addi';
                $addiOrderStatus['PTS_ADDI_REJECTED']['name'][$lang['id_lang']] = 'Rejected - Addi';
                $addiOrderStatus['PTS_ADDI_ABANDONED']['name'][$lang['id_lang']] = 'Abandoned - Addi';
                $addiOrderStatus['PTS_ADDI_DECLINED']['name'][$lang['id_lang']] = 'Declined - Addi';
                $addiOrderStatus['PTS_ADDI_INTERNAL_ERROR']['name'][$lang['id_lang']] = 'Internal error - Addi';
            }
        }

        foreach ($addiOrderStatus as $stateName => $stateData) {
            $orderStateId = $configurationService->get($stateName);
            $orderState = new OrderState($orderStateId);
            if (!empty($orderStateId) && Validate::isLoadedObject($orderState)) {
                continue;
            }

            $orderState->name = $stateData['name'];
            $orderState->send_email = $stateData['send_email'];
            $orderState->color = $stateData['color'];
            $orderState->hidden = $stateData['hidden'];
            $orderState->delivery = $stateData['delivery'];
            $orderState->logable = $stateData['logable'];
            $orderState->invoice = $stateData['invoice'];
            $orderState->module_name = $this->name;

            if ($orderState->add()) {
                $configurationService->set($stateName, $orderState->id);
            }
        }

        return true;
    }

    public function uninstall()
    {
        if (
            !\Pts_Addi\PTSService::get('pts_addi.install.installer')->uninstall() ||
            !parent::uninstall()
        ) {
            return false;
        }

        return true;
    }

    public function getContent()
    {
        if (version_compare(_PS_VERSION_, '1.7.5', '>=')) {
            Tools::redirectAdmin(\Pts_Addi\PTSService::getRoute('admin_addi_dashboard'));
        }

        Media::addJsDef($this->getBackTemplateVarList());

        $this->context->smarty->assign([
            'pathApp' => $this->getPathUri() . 'views/js/admin/admin.js',
            'pathCss' => $this->getPathUri() . 'views/css/admin/admin.css',
        ]);

        return $this->display(__FILE__, 'views/templates/admin/admin.tpl');
    }

    public function getBackTranslationList($messageKey = '')
    {
        $messageList = [
            // Addons
            'viewMore' => $this->l('View more'),
            // Changelog
            'changeLog' => $this->l('Change Log'),
            // Code Editor
            'save' => $this->l('Save'),
            // Filter Option Form
            'selectAnOption' => $this->l('Select an option'),
            'search' => $this->l('Search'),
            // Footer
            'information' => $this->l('Information'),
            'support' => $this->l('Support'),
            'website' => $this->l('Website and store'),
            // Option Form
            'invalidHexadecimal' => $this->l('Invalid Hexadecimal'),
            // Table List
            'clear' => $this->l('Clear'),
            'apply' => $this->l('Apply'),
            'noResultsFound' => $this->l('No results found'),
            'confirmHeaderDelete' => $this->l('Delete confirmation'),
            'confirmDelete' => $this->l('Are you sure you want to delete the record?'),
            'confirmMassiveDelete' => $this->l('Are you sure you want to delete the records?'),
            // Translation
            'file' => $this->l('File'),
            'someExpressionSyntax' => $this->l('Some expressions use the syntax') . '<strong> %s </strong>' . $this->l('do not replace or modify this.'),
            'chooseLanguage' => $this->l('Choose a language'),
            'colapseAll' => $this->l('Collapse all'),
            'expandAll' => $this->l('Expand all'),
            'saveAndDownload' => $this->l('Save and download'),
            'shareWithUs' => $this->l('Share with us'),
            'subjectMailTranslation' => $this->l('Someone shared a translation with you'),
            // Update version
            'updateMessage' => $this->l('We have detected you uploaded the new version'),
            'moduleMessage' => $this->l('of our module'),
            'needToClickToUpdate' => $this->l('To proceed with the update, you need to click here'),
            'updateNow' => $this->l('Update now'),
            'requireChooseStore' => $this->l('You need to update the version of our module for all your stores, please select the option \'All stores\' to perform this process'),
            'chooseAllStores' => $this->l('Choose all stores'),
            // Other
            'create' => $this->l('Create'),
            'add' => $this->l('Add'),
            'edit' => $this->l('Edit'),
            'delete' => $this->l('Delete'),
            'cancel' => $this->l('Cancel'),
            'actions' => $this->l('Actions'),
            'copy' => $this->l('Copy'),
            'open' => $this->l('Open'),
            'subject' => $this->l('Subject'),
            'sslCertificateRequirement' => $this->l('The shop must have a valid ssl certificate to use this module.'),
            // Module
            'callbackMessageInfo' => $this->l('You must contact Addi\'s integrations team and send them your callback username and password via secure email!.'),
        ];

        if (!empty($messageKey) && isset($messageList[$messageKey])) {
            return $messageList[$messageKey];
        }

        return $messageList;
    }

    public function getBackTemplateVarList()
    {
        $contextProvider = \Pts_Addi\PTSService::get('pts_addi.prestashop.provider.context');
        $coreService = \Pts_Addi\PTSService::get('pts_addi.core.core_service');
        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');

        return [
            self::PREFIX => [
                'Module' => $this->getModuleVarList(),
                'Global' => [
                    'languageList' => Language::getLanguages(),
                    'isPrestaShop17' => $coreService->isPrestaShop17(),
                    'isSslEnabled' => $this->isSslEnabled(),
                ],
                'Language' => [
                    'isoCode' => $contextProvider->getLanguageIsoCode(),
                    'defaultId' => $configurationService->get('PS_LANG_DEFAULT'),
                ],
                'Shop' => [
                    'isMultiShop' => Shop::isFeatureActive(),
                    'contextIdShop' => Shop::getContextShopID(),
                ],
                'TranslationList' => $this->getBackTranslationList(),
                'Forms' => [
                    'General' => $this->getGeneralForm(),
                    'Credential' => $this->getCredentialForm(),
                ],
                'Cards' => $this->getCards(),
                'Tabs' => $this->getTabList(),
                'Addons' => $this->getAddons(),
                'RouteList' => $this->getRouteList(),
                'Shop' => [
                    'isMultiShop' => Shop::isFeatureActive(),
                    'contextIdShop' => Shop::getContextShopID(),
                ],
            ],
        ];
    }

    public function getModuleVarList()
    {
        $coreService = \Pts_Addi\PTSService::get('pts_addi.core.core_service');
        $ptsToken = $coreService->getToken($this->name);

        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');
        $requiresUpgrade = $configurationService->get(self::PREFIX . '_VERSION') !== self::VERSION;

        return [
            'name' => $this->name,
            'displayName' => $this->displayName,
            'description' => $this->description,
            'version' => $this->version,
            'domain' => $_SERVER['SERVER_NAME'],
            'ptsToken' => $ptsToken,
            'addons' => false,
            'checksum' => Tools::file_get_contents(dirname(__FILE__) . '/src/checksum'),
            'requiresUpgrade' => $requiresUpgrade,
            'isValid' => $coreService->isModuleValid(),
            'ipAddress' => Tools::getRemoteAddr(),
            'shopEmail' => $configurationService->get('PS_SHOP_EMAIL'),
        ];
    }

    public function getRouteList()
    {
        return [
            'Module' => [
                'updateVersion' => \Pts_Addi\PTSService::getRoute('admin_addi_update_version', [], 'AdminModuleADDI'),
            ],
            'OptionForm' => [
                'save' => \Pts_Addi\PTSService::getRoute('admin_addi_option_form_save', [], 'AdminOptionFormADDI'),
            ],
            'General' => [
                'save' => \Pts_Addi\PTSService::getRoute('admin_addi_general_save', [], 'AdminGeneralADDI'),
            ],
            'Credential' => [
                'save' => \Pts_Addi\PTSService::getRoute('admin_addi_credential_save', [], 'AdminCredentialADDI'),
            ],
            'CodeEditor' => [
                'list' => \Pts_Addi\PTSService::getRoute('admin_addi_code_editor_list', [], 'AdminCodeEditorADDI'),
                'save' => \Pts_Addi\PTSService::getRoute('admin_addi_code_editor_save', [], 'AdminCodeEditorADDI'),
            ],
            'Translation' => [
                'download' => \Pts_Addi\PTSService::getRoute('admin_addi_translation_download', [], 'AdminTranslationADDI'),
                'list' => \Pts_Addi\PTSService::getRoute('admin_addi_translation_list', [], 'AdminTranslationADDI'),
                'save' => \Pts_Addi\PTSService::getRoute('admin_addi_translation_save', [], 'AdminTranslationADDI'),
                'share' => \Pts_Addi\PTSService::getRoute('admin_addi_translation_share', [], 'AdminTranslationADDI'),
            ],
        ];
    }

    private function getCards()
    {
        $cardList = [];
        $cardList['contact'] = [
            'icon' => 'pi pi-external-link',
            'name' => $this->l('Send us a ticket'),
            'link' => 'https://co.addi.com/preguntas-frecuentes',
        ];

        array_push($cardList, [
            'icon' => 'pi pi-file-pdf text-red-500',
            'name' => $this->l('Users Guide'),
            'link' => $this->_path . 'docs/guide/index.html',
        ]);

        return $cardList;
    }

    private function getTabList()
    {
        return [
            [
                'label' => $this->l('General'),
                'icon' => 'pi pi-fw pi-cog',
                'view' => 'general',
            ],
            [
                'label' => $this->l('Credentials'),
                'icon' => 'pi pi-fw pi-user',
                'view' => 'credential',
            ],
            [
                'label' => $this->l('Translation'),
                'icon' => 'pi pi-fw pi-book',
                'view' => 'translation',
            ],
            [
                'label' => $this->l('Code Editors'),
                'icon' => 'pi pi-fw pi-slack',
                'view' => 'codeEditor',
            ],
        ];
    }

    private function getAddons()
    {
        return [];
    }

    private function getGeneralForm()
    {
        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');

        return [
            'OptionList' => [
                'enableDebug' => [
                    'value' => (bool) $configurationService->get('ADDI_ENABLE_DEBUG'),
                    'type' => 'switch',
                    'label' => $this->l('Enable debug'),
                    'dependList' => [
                        'ipDebug' => [
                            'on' => true,
                            'value' => $configurationService->get('ADDI_IP_DEBUG'),
                            'type' => 'text',
                            'label' => $this->l('IP'),
                            'handler' => [
                                'action' => 'addIp',
                                'ip' => Tools::getRemoteAddr(),
                            ],
                            'tooltip' => $this->l('It is recommended that you enable this option to test the module in your store before enabling it for clients.'),
                        ],
                    ],
                ],
                'modifierCheck' => [
                    'value' => false,
                    'type' => 'switch',
                    'label' => $this->l('I want to change the callback user and password to customized ones.'),
                    'tooltip' => $this->l('It is not recommended to change these unless necessary'),
                ],
                'callbackUser' => [
                    'value' => $configurationService->get('ADDI_CALLBACK_USER'),
                    'type' => 'text',
                    'required' => true,
                    'disabled' => true,
                    'label' => $this->l('Callback User'),
                ],
                'callbackPassword' => [
                    'value' => $configurationService->get('ADDI_CALLBACK_PASSWORD'),
                    'type' => 'text',
                    'required' => true,
                    'disabled' => true,
                    'label' => $this->l('Callback Password'),
                ],
            ],
        ];
    }

    private function getCredentialForm()
    {
        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');

        return [
            'OptionList' => [
                'enableSandbox' => [
                    'value' => (bool) $configurationService->get('ADDI_ENABLE_SANDBOX'),
                    'type' => 'switch',
                    'label' => $this->l('Sandbox'),
                ],
                'clientId' => [
                    'value' => $configurationService->get('ADDI_CLIENT_ID'),
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Client ID'),
                ],
                'clientSecret' => [
                    'value' => $configurationService->get('ADDI_CLIENT_SECRET'),
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Client Secret'),
                ],
                'allySlug' => [
                    'value' => $configurationService->get('ADDI_ALLY_SLUG'),
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Ally Slug'),
                ],
            ],
        ];
    }

    public function getFrontTranslationList($messageKey = '')
    {
        $messageList = [];

        if (!empty($messageKey) && isset($messageList[$messageKey])) {
            return $messageList[$messageKey];
        }

        return $messageList;
    }

    public function getFrontTemplateVarList()
    {
        return [];
    }

    private function validateAllowedCurrencies()
    {
        $contextProvider = \Pts_Addi\PTSService::get('pts_addi.prestashop.provider.context');
        $contextCurrencyIsoCode = $contextProvider->getCurrencyIsoCode();

        return in_array($contextCurrencyIsoCode, self::ADDI_ALLOWED_CURRENCIES);
    }

    private function isSslEnabled()
    {
        $configurationService = \Pts_Addi\PTSService::get('pts_addi.prestashop.configuration');

        return (bool) $configurationService->get('PS_SSL_ENABLED');
    }

    public function hookDisplayHeader()
    {
        $coreService = \Pts_Addi\PTSService::get('pts_addi.core.core_service');
        if ($coreService->isBackOffice() || !$coreService->isVisible()) {
            return '';
        }

        $contextProvider = \Pts_Addi\PTSService::get('pts_addi.prestashop.provider.context');

        return \Pts_Addi\PTSService::get('pts_addi.hook.display.header')->run([
            'context' => $contextProvider->getContextLegacy(),
        ]);
    }

    public function hookDisplayProductAdditionalInfo($params)
    {
        $coreService = \Pts_Addi\PTSService::get('pts_addi.core.core_service');
        if (
            $coreService->isBackOffice() ||
            !$coreService->isVisible() ||
            !$this->validateAllowedCurrencies() ||
            !$this->isSslEnabled()
        ) {
            return '';
        }

        return \Pts_Addi\PTSService::get('pts_addi.hook.display.product_additional_info')->run($params) ?? '';
    }

    public function hookPaymentOptions($params)
    {
        $coreService = \Pts_Addi\PTSService::get('pts_addi.core.core_service');
        if (
            !$coreService->isVisible() ||
            !$this->validateAllowedCurrencies() ||
            !$this->isSslEnabled()
        ) {
            return '';
        }

        return \Pts_Addi\PTSService::get('pts_addi.hook.payment_options')->run($params) ?? '';
    }

    public function isUsingNewTranslationSystem()
    {
        return false;
    }
}
