<?php
/**
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * @author    Addi <soporte@addi.com>
 * @copyright 2024 Addi, All rights reserved.
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *
 * @category  PrestaShop
 * @category  Module
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_5_0_3($module)
{
    $module = $module;

    if (version_compare(_PS_VERSION_, '1.7.3', '>=')) {
        $customerAddress = new CustomerAddress();
        $requiredFields = $customerAddress->getFieldsRequiredDB();
        if (!in_array('phone_mobile', $requiredFields)) {
            $customerAddress->addFieldsRequiredDatabase(['phone_mobile']);
        }
    }

    return true;
}
