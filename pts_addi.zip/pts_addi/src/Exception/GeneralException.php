<?php
namespace Pts_Addi\Exception;

class GeneralException extends PTSException
{
    public const EMPTY_CALLBACK_USER = 1;
    public const EMPTY_CALLBACK_PASSWORD = 2;
}
