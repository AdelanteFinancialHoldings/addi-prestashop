<?php
namespace Pts_Addi\Exception;

use Exception;

class PTSException extends Exception
{
    protected $parameters;

    public const UNKNOWN = 0;
    public const PARAMETER_NOT_SENT = 1;

    public function __construct($message, $code, $parameters = [])
    {
        parent::__construct($message, $code);

        $this->parameters = $parameters;
    }

    public function getMessageFormatted($messageLang)
    {
        if (count($this->parameters) > 0 && !empty($messageLang)) {
            return vsprintf($messageLang, $this->parameters);
        }

        if (empty($messageLang)) {
            return parent::getMessage();
        }

        return $messageLang;
    }
}
