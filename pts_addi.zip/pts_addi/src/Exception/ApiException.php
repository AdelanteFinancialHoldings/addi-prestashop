<?php
namespace Pts_Addi\Exception;

class ApiException extends PTSException
{
    public const TOKEN_ERROR = 1;
    public const BAD_REQUEST = 400;
    public const UNAUTHORIZED = 401;
    public const FORBIDDEN = 403;
    public const NOT_FOUND = 404;
}
