<?php
namespace Pts_Addi\Exception;

class TranslationException extends PTSException
{
    public const FILE_NOT_FOUND = 1;
    public const ERROR_PERMISSION_FILE = 2;
    public const UNABLE_OPEN_FILE = 3;
    public const ERROR_SAVING = 4;
    public const ERROR_SENDING_MAIL = 5;
}
