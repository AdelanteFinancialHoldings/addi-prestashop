<?php
namespace Pts_Addi\Exception;

class CodeEditorException extends PTSException
{
    public const ERROR_PERMISSION_FILE = 1;
    public const ERROR_SAVING = 2;
}
