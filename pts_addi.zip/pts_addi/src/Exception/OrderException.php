<?php
namespace Pts_Addi\Exception;

class OrderException extends PTSException
{
    public const CART_DOESNT_EXISTS = 1;
    public const CUSTOMER_DOESNT_EXISTS = 2;
    public const CURRENCY_DOESNT_EXISTS = 3;
    public const CARRIER_DOESNT_EXISTS = 4;
    public const BILLING_ADDRESS_DOESNT_EXISTS = 5;
    public const COUNTRY_DOESNT_EXISTS = 6;
    public const UNPROCESSABLE_CONTENT = 422;
}
