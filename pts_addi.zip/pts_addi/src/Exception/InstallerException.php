<?php
namespace Pts_Addi\Exception;

class InstallerException extends PTSException
{
    public const UNABLE_EXECUTE_QUERY = 1;
    public const COUNTRY_CO_DOESNT_EXISTS = 2;
}
