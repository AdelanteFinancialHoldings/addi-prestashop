<?php
namespace Pts_Addi\Exception;

class OptionFormException extends PTSException
{
    public const EMPTY_DATA = 1;
    public const SAVING_ERROR = 2;
}
