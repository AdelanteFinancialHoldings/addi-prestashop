<?php
namespace Pts_Addi\Exception;

class CredentialException extends PTSException
{
    public const EMPTY_CLIENT_KEYS = 1;
    public const EMPTY_ALLY_SLUG = 2;
    public const EMPTY_TOKEN = 3;
}
