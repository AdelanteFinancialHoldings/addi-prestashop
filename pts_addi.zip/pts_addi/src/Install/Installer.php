<?php
namespace Pts_Addi\Install;

use Db;
use Language;
use Pts_Addi\Application\PrestaShop\Configuration\Configuration;
use Pts_Addi\Application\PrestaShop\Provider\ContextProvider;
use Pts_Addi as PTSModule;
use Pts_Addi\Exception\InstallerException;
use Shop;
use Tab;
use Tools;

class Installer
{
    private $configuration;
    private $module;
    private $contextProvider;

    public function __construct(PTSModule $module, ContextProvider $contextProvider, Configuration $configuration)
    {
        $this->module = $module;
        $this->configuration = $configuration;
        $this->contextProvider = $contextProvider;
    }

    public function install()
    {
        return $this->registerHooks()
            && $this->installTables()
            && $this->insertQueriesByShop()
            && $this->insertQueriesByLang()
            && $this->installConfiguration()
            && $this->installTabs()
            && $this->clearSmartyCache()
        ;
    }

    public function uninstall()
    {
        return $this->uninstallTables()
            && $this->uninstallConfiguration()
            && $this->clearSmartyCache()
        ;
    }

    protected function clearSmartyCache()
    {
        $smarty = $this->contextProvider->getSmarty();

        Tools::clearCache($smarty);
        Tools::clearCompile($smarty);

        if (file_exists(_PS_ROOT_DIR_ . '/var/cache/dev/class_index.php')) {
            unlink(_PS_ROOT_DIR_ . '/var/cache/dev/class_index.php');
        }
        if (file_exists(_PS_ROOT_DIR_ . '/var/cache/prod/class_index.php')) {
            unlink(_PS_ROOT_DIR_ . '/var/cache/prod/class_index.php');
        }

        return true;
    }

    private function installMainTab()
    {
        $tab = new Tab();
        $tab->class_name = 'AdminDashboard' . PTSModule::PREFIX;
        $tab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = PTSModule::TAB_NAME;
        }
        $tab->id_parent = (int) Tab::getIdFromClassName('AdminParentModulesSf');
        $tab->module = PTSModule::NAME;
        $tab->enabled = true;

        if (property_exists($tab, 'route_name')) {
            $tab->route_name = 'admin_' . strtolower(PTSModule::PREFIX) . '_dashboard';
        }

        return $tab->add();
    }

    private function installTab($tabName, $tabMainId)
    {
        $tab = new Tab();
        $tab->active = false;
        $tab->class_name = $tabName . PTSModule::PREFIX;
        $tab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $tabName;
        }
        $tab->id_parent = $tabMainId;
        $tab->module = PTSModule::NAME;
        $tab->enabled = false;

        return $tab->add();
    }

    private function installTabs()
    {
        $tabMainId = $this->installMainTab();

        if (PTSModule::$moduleTabList) {
            foreach (PTSModule::$moduleTabList as $tabName) {
                if (Tab::getIdFromClassName($tabName)) {
                    continue;
                }

                if (!$this->installTab($tabName, $tabMainId)) {
                    return false;
                }
            }
        }

        return true;
    }

    private function registerHooks()
    {
        return (bool) $this->module->registerHook(PTSModule::$moduleHookList);
    }

    private function installTables()
    {
        return (bool) $this->executeQueries($this->module->getModuleQueries()['install']);
    }

    private function uninstallTables()
    {
        return (bool) $this->executeQueries($this->module->getModuleQueries()['uninstall']);
    }

    private function installConfiguration()
    {
        if (PTSModule::$moduleConfigList) {
            foreach (PTSModule::$moduleConfigList as $key => $config) {
                $this->configuration->set(
                    $key,
                    $config['options']['default_value'],
                    $config['options']
                );
            }
        }

        $this->configuration->set(
            PTSModule::PREFIX . '_VERSION',
            PTSModule::VERSION,
            [
                'id_shop' => 0,
                'id_shop_group' => 0,
            ]
        );

        return true;
    }

    private function uninstallConfiguration()
    {
        if (PTSModule::$moduleConfigList) {
            foreach (array_keys(PTSModule::$moduleConfigList) as $key) {
                $this->configuration->remove($key);
            }
        }

        $this->configuration->remove(PTSModule::PREFIX . '_VERSION');

        return true;
    }

    public function insertQueriesByShop($shopList = null)
    {
        if (empty($shopList)) {
            $shopList = Shop::getShops();
            $shopList = array_keys($shopList);
        } elseif (is_array($shopList)) {
            $shopList = array_values($shopList);
        } else {
            $shopList = [$shopList];
        }

        $moduleQueries = $this->module->getModuleQueries();
        if (is_array($moduleQueries) && isset($moduleQueries['shop'])) {
            $shopQueries = $moduleQueries['shop'];
            if ($shopQueries) {
                foreach ($shopQueries as $query) {
                    foreach ($shopList as $shopId) {
                        $queryShop = str_replace('ID_SHOP', $shopId, $query);

                        $this->executeQueries($queryShop);
                    }
                }
            }
        }

        return true;
    }

    public function insertQueriesByLang($langList = null)
    {
        if (empty($langList)) {
            $langList = Language::getLanguages(false);
        } elseif (is_array($langList)) {
            foreach ($langList as $key => $langId) {
                $langList[$key] = Language::getLanguage($langId);
            }
        } else {
            $langList = [Language::getLanguage($langList)];
        }

        $shopList = Shop::getShops();
        $shopList = array_keys($shopList);
        foreach ($langList as $lang) {
            $isoCode = 'en';
            if (file_exists(dirname(__FILE__) . '/../../sql/languages/' . Tools::strtolower($lang['iso_code']) . '.sql')) {
                $isoCode = Tools::strtolower($lang['iso_code']);
            }

            $queries = Tools::file_get_contents(dirname(__FILE__) . '/../../sql/languages/' . $isoCode . '.sql');
            if ($queries) {
                $queries = str_replace('PREFIX_', _DB_PREFIX_, $queries);
                $queries = str_replace('ID_LANG', $lang['id_lang'], $queries);

                if (strpos($queries, 'ID_SHOP')) {
                    foreach ($shopList as $shopId) {
                        $queryShop = str_replace('ID_SHOP', $shopId, $queries);
                        $queryShop = preg_split("/;\s*[\r\n]+/", $queryShop);

                        $this->executeQueries($queryShop);
                    }
                } else {
                    $this->executeQueries($queries);
                }
            }
        }

        return true;
    }

    private function executeQueries($queries)
    {
        if ($queries) {
            $db = Db::getInstance(_PS_USE_SQL_SLAVE_);

            if (!is_array($queries)) {
                $queries = [$queries];
            }

            foreach ($queries as $query) {
                $result = $db->execute(trim($query));
                if ($result === false) {
                    $errorList = [
                        'query' => $query,
                    ];

                    throw new InstallerException(
                        vsprintf('Unable to execute the following query: %s', $errorList),
                        InstallerException::UNABLE_EXECUTE_QUERY,
                        $errorList
                    );
                }
            }
        }

        return true;
    }
}
