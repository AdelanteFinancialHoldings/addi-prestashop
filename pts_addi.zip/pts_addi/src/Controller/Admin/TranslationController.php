<?php
namespace Pts_Addi\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\Exception\TranslationException;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class TranslationController extends FrameworkBundleAdminController
{
    private $module;

    public function listAction(Request $request)
    {
        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            $response = PTSService::get('pts_addi.core.translation.list_service')
                ->setParameters($requestParameters)
                ->list();
        } catch (PTSException $exception) {
            $response = [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }

        return new Response(
            json_encode($response),
            Response::HTTP_OK,
            ['content-type' => 'application/json']
        );
    }

    public function saveAction(Request $request)
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            PTSService::get('pts_addi.core.translation.save_service')
                ->setParameters($requestParameters)
                ->save();

            return new Response(
                json_encode(
                    [
                        'success' => true,
                        'message' => $this->module->l('The translations have been successfully saved', basename(__FILE__, '.php')),
                    ]
                ),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        } catch (PTSException $exception) {
            return new Response(
                json_encode(
                    [
                        'success' => false,
                        'message' => $this->handleExceptionAjax($exception),
                    ]
                ),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        }
    }

    public function shareAction(Request $request)
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            PTSService::get('pts_addi.core.translation.share_service')
                ->setParameters($requestParameters)
                ->share();

            return new Response(
                json_encode(
                    [
                        'success' => true,
                        'message' => $this->module->l(
                            'Your translation has been sent, we will consider it for future upgrades of the module',
                            basename(__FILE__, '.php')
                        ),
                    ]
                ),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        } catch (PTSException $exception) {
            return new Response(
                json_encode(
                    [
                        'success' => false,
                        'message' => $this->handleExceptionAjax($exception),
                    ]
                ),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        }
    }

    public function downloadAction(Request $request)
    {
        $requestParameters['languageIsoCode'] = $request->query->get('languageIsoCode');

        $response = PTSService::get('pts_addi.core.translation.download_service')
            ->setParameters($requestParameters)
            ->downloadFile();

        return new Response(
            json_encode($response),
            Response::HTTP_OK,
            ['content-type' => 'application/json']
        );
    }

    public function handleExceptionAjax($exception)
    {
        $this->module = PTSService::get('pts_addi.module');

        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\TranslationException') {
            switch ($exception->getCode()) {
                case TranslationException::FILE_NOT_FOUND:
                    $messageLang = $this->module->l('The file was not found at the specified path', basename(__FILE__, '.php'));
                    break;
                case TranslationException::ERROR_PERMISSION_FILE:
                    $messageLang = $this->module->l('You do not have write permission in the translations file', basename(__FILE__, '.php'));
                    break;
                case TranslationException::UNABLE_OPEN_FILE:
                    $messageLang = $this->module->l('Unable to open file', basename(__FILE__, '.php'));
                    break;
                case TranslationException::ERROR_SAVING:
                    $messageLang = $this->module->l('An error has occurred while attempting to save the translations', basename(__FILE__, '.php'));
                    break;
                case TranslationException::ERROR_SENDING_MAIL:
                    $messageLang = $this->module->l('An error has occurred to attempt send the translation', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
