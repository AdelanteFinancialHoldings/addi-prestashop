<?php
namespace Pts_Addi\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\Exception\GeneralException;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class GeneralController extends FrameworkBundleAdminController
{
    private $module;

    public function saveAction(Request $request)
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            PTSService::get('pts_addi.core.general.save_service')
                ->setParameters($requestParameters)
                ->save();

            return new Response(
                json_encode([
                    'success' => true,
                    'message' => $this->module->l('The information was successfully saved.', basename(__FILE__, '.php')),
                ]),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        } catch (PTSException $exception) {
            return new Response(
                json_encode([
                    'success' => false,
                    'message' => $this->handleExceptionAjax($exception),
                ]),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        }
    }

    public function handleExceptionAjax($exception)
    {
        $this->module = PTSService::get('pts_addi.module');

        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\GeneralException') {
            switch ($exception->getCode()) {
                case GeneralException::EMPTY_CALLBACK_USER:
                    $messageLang = $this->module->l('Callback user is required for the request', basename(__FILE__, '.php'));
                    break;
                case GeneralException::EMPTY_CALLBACK_PASSWORD:
                    $messageLang = $this->module->l('Callback password is required for the request', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
