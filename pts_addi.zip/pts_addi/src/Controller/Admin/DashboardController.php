<?php
namespace Pts_Addi\Controller\Admin;

use Media;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\PTSService;

class DashboardController extends FrameworkBundleAdminController
{
    public function indexAction()
    {
        $module = PTSService::get('pts_addi.module');

        Media::addJsDef($module->getBackTemplateVarList());

        return $this->render('@Modules/pts_addi/views/templates/admin/admin.html.twig', [
            'layoutTitle' => $module::TAB_NAME,
        ]);
    }
}
