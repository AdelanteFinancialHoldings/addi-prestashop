<?php

namespace Pts_Addi\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\Application\Core\CoreService;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Response;

class ModuleController extends FrameworkBundleAdminController
{
    private $module;

    public function updateVersionAction()
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $return = CoreService::updateVersion($this->module);
            $response = [
                'success' => true,
            ];

            if ($return === false) {
                $response['message'] = $this->module->l('There is a problem updating the module, please contact the developers', basename(__FILE__, '.php'));
            } elseif ($return !== true) {
                $response['message'] = $return;
            }
        } catch (PTSException $exception) {
            $response = [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }

        return new Response(
            json_encode($response),
            Response::HTTP_OK,
            ['content-type' => 'application/json']
        );
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = $exception->getMessage();

        return $exception->getMessageFormatted($messageLang);
    }
}
