<?php
namespace Pts_Addi\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\Exception\CodeEditorException;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class CodeEditorController extends FrameworkBundleAdminController
{
    private $module;

    public function listAction()
    {
        $codeEditor = PTSService::get('pts_addi.core.code_editor.list_service')->list();

        return new Response(
            json_encode($codeEditor),
            Response::HTTP_OK,
            ['content-type' => 'application/json']
        );
    }

    public function saveAction(Request $request)
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            PTSService::get('pts_addi.core.code_editor.save_service')
                ->setParameters($requestParameters)
                ->save();

            return new Response(
                json_encode([
                    'success' => true,
                    'message' => $this->module->l('The code was successfully saved.', basename(__FILE__, '.php')),
                ]),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        } catch (PTSException $exception) {
            return new Response(
                json_encode([
                    'success' => false,
                    'message' => $this->handleExceptionAjax($exception),
                ]),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        }
    }

    public function handleExceptionAjax($exception)
    {
        $this->module = PTSService::get('pts_addi.module');

        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\CodeEditorException') {
            switch ($exception->getCode()) {
                case CodeEditorException::ERROR_PERMISSION_FILE:
                    $messageLang = $this->module->l('You do not have write permission in the translations file.', basename(__FILE__, '.php'));
                    break;
                case CodeEditorException::ERROR_SAVING:
                    $messageLang = $this->module->l('Failed to save changes.', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
