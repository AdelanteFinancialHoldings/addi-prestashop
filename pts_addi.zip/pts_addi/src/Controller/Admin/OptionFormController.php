<?php
namespace Pts_Addi\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\Exception\OptionFormException;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class OptionFormController extends FrameworkBundleAdminController
{
    private $module;

    public function saveAction(Request $request)
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            PTSService::get('pts_addi.core.option_form.save')
                ->setParameters($requestParameters)
                ->save();

            return new Response(
                json_encode(
                    [
                        'success' => true,
                        'message' => $this->module->l('The configuration was saved successfully', basename(__FILE__, '.php')),
                    ]
                ),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        } catch (PTSException $exception) {
            return new Response(
                json_encode(
                    [
                        'success' => false,
                        'message' => $this->handleExceptionAjax($exception),
                    ]
                ),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        }
    }

    public function handleExceptionAjax($exception)
    {
        $this->module = PTSService::get('pts_addi.module');

        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\OptionFormException') {
            switch ($exception->getCode()) {
                case OptionFormException::EMPTY_DATA:
                    $messageLang = $this->module->l('The data cannot be sent empty.', basename(__FILE__, '.php'));
                    break;
                case OptionFormException::SAVING_ERROR:
                    $messageLang = $exception->getMessage();
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
