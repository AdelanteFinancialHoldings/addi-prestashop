<?php
namespace Pts_Addi\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Pts_Addi\Exception\ApiException;
use Pts_Addi\Exception\CredentialException;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class CredentialController extends FrameworkBundleAdminController
{
    private $module;

    public function saveAction(Request $request)
    {
        $this->module = PTSService::get('pts_addi.module');

        try {
            $requestParameters = $request->getContent();
            $requestParameters = json_decode($requestParameters, true);

            PTSService::get('pts_addi.core.credential.save_service')
                ->setParameters($requestParameters)
                ->save();

            return new Response(
                json_encode([
                    'success' => true,
                    'message' => $this->module->l('The credentials was successfully saved.', basename(__FILE__, '.php')),
                ]),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        } catch (PTSException $exception) {
            $configurationService = PTSService::get('pts_addi.prestashop.configuration');
            $configurationService->set('ADDI_ENABLE_SANDBOX', true);
            $configurationService->set('ADDI_CLIENT_ID', '');
            $configurationService->set('ADDI_CLIENT_SECRET', '');
            $configurationService->set('ADDI_ALLY_SLUG', '');
            $configurationService->set('ADDI_TOKEN', '');

            return new Response(
                json_encode([
                    'success' => false,
                    'message' => $this->handleExceptionAjax($exception),
                ]),
                Response::HTTP_OK,
                ['content-type' => 'application/json']
            );
        }
    }

    public function handleExceptionAjax($exception)
    {
        $this->module = PTSService::get('pts_addi.module');

        $messageLang = '';
        $exceptionClass = get_class($exception);
        $exceptionCode = $exception->getCode();
        $exceptionMessage = $exception->getMessage();

        if ($exceptionClass == 'Pts_Addi\Exception\CredentialException') {
            if ($exceptionCode == CredentialException::EMPTY_CLIENT_KEYS) {
                $messageLang = $this->module->l('Client ID and Client Secret are required for the request.', basename(__FILE__, '.php'));
            } elseif ($exceptionCode == CredentialException::EMPTY_ALLY_SLUG) {
                $messageLang = $this->module->l('Ally slug is required for the request.', basename(__FILE__, '.php'));
            }
        } elseif ($exceptionClass == 'Pts_Addi\Exception\ApiException') {
            if ($exceptionCode == ApiException::TOKEN_ERROR) {
                $messageLang = $this->module->l('The token property has not been returned.', basename(__FILE__, '.php'));
            } elseif ($exceptionCode == ApiException::BAD_REQUEST) {
                $messageLang = sprintf(
                    $this->module->l('HTTP %d: The request could not be understood or is asking for a resource that does not exist.', basename(__FILE__, '.php')),
                    ApiException::BAD_REQUEST
                );
            } elseif ($exceptionCode == ApiException::UNAUTHORIZED) {
                $messageLang = sprintf(
                    $this->module->l('HTTP %d: Authentication credentials were missing or incorrect.', basename(__FILE__, '.php')),
                    ApiException::UNAUTHORIZED
                );
            } elseif ($exceptionCode == ApiException::FORBIDDEN) {
                $messageLang = sprintf(
                    $this->module->l('HTTP %d: You do not have permission to access this resource.', basename(__FILE__, '.php')),
                    ApiException::FORBIDDEN
                );
            } elseif ($exceptionCode == ApiException::NOT_FOUND) {
                $messageLang = sprintf(
                    $this->module->l('HTTP %d: The resource you are looking for could not be found.', basename(__FILE__, '.php')),
                    ApiException::NOT_FOUND
                );
            } else {
                $messageLang = $exceptionMessage;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
