<?php
namespace Pts_Addi\Controller\Front;

interface FrontControllerInterface
{
    public function postProcess();

    public function handleExceptionAjax($exception);
}
