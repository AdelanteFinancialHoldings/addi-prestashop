<?php
namespace Pts_Addi\Repository;

use Doctrine\ORM\EntityRepository;
use Pts_Addi\Entity\AddiOrder;

class OrderRepository extends EntityRepository
{
    public function getCurrentOrderByCartId($cartId)
    {
        $orderAddiId = AddiOrder::PREFIX_ID . $cartId . '-';

        $subQuery = $this->createQueryBuilder('o2')
            ->select('MAX(o2.dateAdd)')
            ->where('o2.idOrderAddi LIKE :orderAddiId');

        $qb = $this->createQueryBuilder('o')
            ->where('o.idOrderAddi LIKE :orderAddiId')
            ->andWhere('o.dateAdd = (' . $subQuery->getDQL() . ')')
            ->setParameter('orderAddiId', $orderAddiId . '%');

        return $qb->getQuery()->getOneOrNullResult();
    }
}
