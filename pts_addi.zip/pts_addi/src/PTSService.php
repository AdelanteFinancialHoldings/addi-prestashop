<?php
namespace Pts_Addi;

if (!defined('_PS_VERSION_')) {
    exit;
}

// Revision: 1

use PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer;
use PrestaShop\PrestaShop\Adapter\ContainerBuilder;
use Pts_Addi as PTSModule;

class PTSService
{
    private static $serviceContainer;
    private static $frontServiceContainer;
    private static $entityManager;
    private static $dbalConnection;
    private static $serviceList;
    private static $sfContainer;

    public static function get($serviceName)
    {
        if (is_null(self::$serviceContainer)) {
            $localPath = _PS_MODULE_DIR_ . PTSModule::NAME . '/';

            self::$serviceContainer = new ServiceContainer(
                PTSModule::NAME . str_replace('.', '', PTSModule::VERSION),
                $localPath
            );
        }

        if (isset(self::$serviceList[$serviceName])) {
            return self::$serviceList[$serviceName];
        }

        self::$serviceList[$serviceName] = self::$serviceContainer->getService($serviceName);

        return self::$serviceList[$serviceName];
    }

    public static function getPSFrontService($serviceName)
    {
        if (is_null(self::$frontServiceContainer)) {
            self::$frontServiceContainer = ContainerBuilder::getContainer('front', _PS_MODE_DEV_);
        }

        return self::$frontServiceContainer->get($serviceName);
    }

    public static function getEntityManager()
    {
        if (is_null(self::$entityManager)) {
            if (version_compare(_PS_VERSION_, '1.7.6', '>=')) {
                self::$entityManager = self::getPSFrontService('doctrine.orm.entity_manager');
            } else {
                // necesita el composer "doctrine/orm": "^2.12"
                require_once dirname(__FILE__) . '/TablePrefix.php';

                $connectionParams = [
                    'dbname' => _DB_NAME_,
                    'user' => _DB_USER_,
                    'password' => _DB_PASSWD_,
                    'host' => _DB_SERVER_,
                    'driver' => 'pdo_mysql',
                    'charset' => 'UTF8',
                ];
                $config = \Doctrine\ORM\Tools\Setup::createAnnotationMetadataConfiguration([__DIR__ . '/Entity/'], false, null, null, false);

                $namingStrategy = new \Doctrine\ORM\Mapping\UnderscoreNamingStrategy(CASE_LOWER);
                $config->setNamingStrategy($namingStrategy);

                $evm = new \Doctrine\Common\EventManager();
                $tablePrefix = new \DoctrineExtensions\TablePrefix(_DB_PREFIX_);
                $evm->addEventListener(\Doctrine\ORM\Events::loadClassMetadata, $tablePrefix);

                self::$entityManager = \Doctrine\ORM\EntityManager::create($connectionParams, $config, $evm);
            }
        }

        return self::$entityManager;
    }

    public static function getDbalConnection()
    {
        if (is_null(self::$dbalConnection)) {
            if (version_compare(_PS_VERSION_, '1.7.6', '>=')) {
                self::$dbalConnection = self::getPSFrontService('doctrine.dbal.default_connection');
            } else {
                // necesita el composer "doctrine/dbal": "^2.13"
                $connectionParams = [
                    'dbname' => _DB_NAME_,
                    'user' => _DB_USER_,
                    'password' => _DB_PASSWD_,
                    'host' => _DB_SERVER_,
                    'driver' => 'pdo_mysql',
                    'charset' => 'UTF8',
                ];
                self::$dbalConnection = \Doctrine\DBAL\DriverManager::getConnection($connectionParams);
            }
        }

        return self::$dbalConnection;
    }

    public static function getRoute($routeName, $routeParams = [], $adminControllerName = null)
    {
        if (version_compare(_PS_VERSION_, '1.7.5', '>=')) {
            if (is_null(self::$sfContainer)) {
                self::$sfContainer = \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance();
            }

            return self::$sfContainer->get('router')->generate($routeName, $routeParams);
        } else {
            return \Context::getContext()->link->getAdminLink($adminControllerName);
        }
    }
}
