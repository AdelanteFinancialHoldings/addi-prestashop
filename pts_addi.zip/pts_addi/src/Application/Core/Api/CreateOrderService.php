<?php
namespace Pts_Addi\Application\Core\Api;

use Pts_Addi\PTSService;

class CreateOrderService extends ApiService
{
    private const URL_SANDBOX = 'https://api.addi-staging.com';
    private const URL_PRODUCTION = 'https://api.addi.com';
    private const ENDPOINT = '/v1/online-applications';

    public function create()
    {
        $url = $this->isSandBox() ? self::URL_SANDBOX : self::URL_PRODUCTION;
        $token = PTSService::get('pts_addi.core.api.create_token_service')->create();
        $body = $this->getParameter('body');

        $optionList = [
            'max_redirects' => 0,
            'headers' => [
                'Authorization' => $token->token_type . ' ' . $token->access_token,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'body' => json_encode($body),
        ];

        $requestParameters = [
            'method' => 'POST',
            'url' => $url . self::ENDPOINT,
            'optionList' => $optionList,
        ];

        return $this->setParameters($requestParameters)->sendRequest();
    }
}
