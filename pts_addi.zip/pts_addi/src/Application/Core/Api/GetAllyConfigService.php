<?php

namespace Pts_Addi\Application\Core\Api;

class GetAllyConfigService extends ApiService
{
    private const DOMAIN_SANDBOX = 'addi-staging';
    private const DOMAIN_PRODUCTION = 'addi';
    private const ALLY_URL = 'https://channels-public-api.{DOMAIN}.com/allies/{ALLY}/config';

    public function getAllyConfig()
    {
        $allySlug = $this->configurationService->get('ADDI_ALLY_SLUG');
        $domain = $this->isSandBox() ? self::DOMAIN_SANDBOX : self::DOMAIN_PRODUCTION;

        $search = ['{DOMAIN}', '{ALLY}'];
        $replace = [$domain, $allySlug];

        $url = str_replace($search, $replace, self::ALLY_URL);

        $optionList = [
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
        ];

        $requestParameters = [
            'method' => 'GET',
            'url' => $url,
            'optionList' => $optionList,
        ];

        return $this->setParameters($requestParameters)->sendRequest();
    }
}
