<?php
namespace Pts_Addi\Application\Core\Api;

use Pts_Addi\Exception\ApiException;

class CreateTokenService extends ApiService
{
    private const URL_SANDBOX = 'https://auth.addi-staging.com';
    private const URL_PRODUCTION = 'https://auth.addi.com';
    private const AUDIENCE_URL_SANDBOX = 'https://api.staging.addi.com';
    private const AUDIENCE_URL_PRODUCTION = 'https://api.addi.com';
    private const GRANT_TYPE = 'client_credentials';
    private const ENDPOINT = '/oauth/token';

    public function create()
    {
        $url = $this->isSandBox() ? self::URL_SANDBOX : self::URL_PRODUCTION;
        $audienceUrl = $this->isSandBox() ? self::AUDIENCE_URL_SANDBOX : self::AUDIENCE_URL_PRODUCTION;
        $clientId = $this->configurationService->get('ADDI_CLIENT_ID');
        $clientSecret = $this->configurationService->get('ADDI_CLIENT_SECRET');

        $body = [
            'audience' => $audienceUrl,
            'grant_type' => self::GRANT_TYPE,
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
        ];

        $optionList = [
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'body' => json_encode($body),
        ];

        $requestParameters = [
            'method' => 'POST',
            'url' => $url . self::ENDPOINT,
            'optionList' => $optionList,
        ];

        $token = $this->setParameters($requestParameters)->sendRequest();
        if (!property_exists($token, 'access_token')) {
            throw new ApiException(
                'The token property has not been returned',
                ApiException::TOKEN_ERROR
            );
        }

        return $token;
    }
}
