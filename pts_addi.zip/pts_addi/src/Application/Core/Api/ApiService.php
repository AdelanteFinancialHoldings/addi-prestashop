<?php
namespace Pts_Addi\Application\Core\Api;

use Pts_Addi\Application\Core\AbstractService;
use Pts_Addi\Exception\ApiException;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Contracts\HttpClient\Exception\HttpExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

class ApiService extends AbstractService
{
    protected $isSandbox;

    public function __construct()
    {
        $this->init();
    }

    protected function isSandBox()
    {
        return $this->configurationService->get('ADDI_ENABLE_SANDBOX');
    }

    protected function sendRequest()
    {
        $method = $this->getParameter('method');
        $url = $this->getParameter('url');
        $optionList = $this->getParameter('optionList');
        $httpClient = HttpClient::create();

        try {
            $response = $httpClient->request($method, $url, $optionList);
            if ($response->getStatusCode() === 301) {
                return $response->getHeaders(false)['location'][0] ?? null;
            } else {
                $content = $response->getContent();
            }
        } catch (HttpExceptionInterface $e) {
            throw new ApiException($e->getMessage(), $e->getResponse()->getStatusCode());
        } catch (TransportExceptionInterface $e) {
            throw new ApiException($e->getMessage(), $e->getCode());
        }

        return json_decode($content);
    }
}
