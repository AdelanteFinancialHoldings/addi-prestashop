<?php
namespace Pts_Addi\Application\Core;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Db;
use DbQuery;
use Module;
use Pts_Addi as PTSModule;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Csrf\CsrfToken;
use Symfony\Component\Security\Csrf\CsrfTokenManager;
use Tools;
use Validate;

// Revision: 2
class CoreService
{
    private $contextProvider;
    private $tokenManager;

    public function __construct()
    {
        $this->contextProvider = PTSService::get(Tools::strtolower(PTSModule::NAME) . '.prestashop.provider.context');
        $this->tokenManager = new CsrfTokenManager();
    }

    public function isModuleActive($moduleName, $functionExist = false)
    {
        if (Module::isInstalled($moduleName)) {
            $module = Module::getInstanceByName($moduleName);
            if (Validate::isLoadedObject($module) && $module->active) {
                if ($moduleName === PTSModule::NAME) {
                    if (!$this->isVisible()) {
                        return false;
                    }
                }

                $sql = new DbQuery();
                $sql->from('module_shop', 'm');
                $sql->where('m.id_module = ' . (int) $module->id);
                $sql->where('m.enable_device & ' . (int) $this->contextProvider->getDevice());
                $sql->where('m.id_shop = ' . (int) $this->contextProvider->getShopId());

                $deviceActived = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

                if ($deviceActived) {
                    if ($functionExist) {
                        if (method_exists($module, $functionExist)) {
                            return $module;
                        } else {
                            return false;
                        }
                    }

                    return $module;
                }
            }
        }

        return false;
    }

    public function isVisible()
    {
        $displayModule = true;

        $configurationService = PTSService::get(Tools::strtolower(PTSModule::NAME) . '.prestashop.configuration');

        $isDebugEnabled = $configurationService->get(PTSModule::PREFIX . '_ENABLE_DEBUG');
        if ($isDebugEnabled) {
            $displayModule = false;
            $myIp = Tools::getRemoteAddr();
            $debugIpList = $configurationService->get(PTSModule::PREFIX . '_IP_DEBUG');

            if (in_array($myIp, explode(',', $debugIpList))) {
                $displayModule = true;
            }
        }

        if ($displayModule) {
            $moduleVersionRegistered = $configurationService->get(PTSModule::PREFIX . '_VERSION');
            if ($moduleVersionRegistered != PTSModule::VERSION) {
                $displayModule = false;
            }
        }

        return $displayModule;
    }

    public function getToken($tokenId)
    {
        return $this->tokenManager->getToken($tokenId)->getValue();
    }

    public function isTokenValid($tokenId, $token)
    {
        return $this->tokenManager->isTokenValid(new CsrfToken($tokenId, $token));
    }

    public function validateAjaxRequest($tokenId, $ptsToken)
    {
        if (empty($ptsToken) ||
            !$this->isTokenValid($tokenId, $ptsToken) ||
            !$this->isAjaxRequest()
        ) {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Execution not allowed.</h1>';
            exit;
        }
    }

    public function validateActionRequest($class, $action)
    {
        if (empty($action) ||
            !method_exists($class, $action)
        ) {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>The action was not found.</h1>';
            exit;
        }
    }

    public function isAjaxRequest()
    {
        return true;
    }

    public function isPrestaShop17()
    {
        return version_compare(_PS_VERSION_, '1.7.0.0', '>=');
    }

    public function isBackOffice()
    {
        return defined('_PS_ADMIN_DIR_') || defined('PS_INSTALLATION_IN_PROGRESS') || PHP_SAPI === 'cli';
    }

    public function executeActionRequest($class, $tokenId = '')
    {
        $requestParameters = $class->getRequestParameters();
        if ($requestParameters) {
            $action = $requestParameters['action'];
            $ptsToken = $requestParameters['ptsToken'];
        } else {
            $action = Tools::getValue('action');
            $ptsToken = Tools::getValue('ptsToken');
        }

        if (empty($tokenId)) {
            $tokenId = PTSModule::NAME;
        }

        $this->validateAjaxRequest($tokenId, $ptsToken);
        $this->validateActionRequest($class, $action);

        $response = $class->{$action}();
        $dataType = Tools::getValue('dataType', 'json');
        if ($dataType === 'json') {
            $response = (new JsonResponse(
                $response,
                Response::HTTP_OK
            ))->getContent();
        }

        exit($response);
    }

    public static function updateVersion($module)
    {
        $configurationService = PTSService::get(Tools::strtolower(PTSModule::NAME) . '.prestashop.configuration');

        $registeredVersion = $configurationService->get(PTSModule::PREFIX . '_VERSION');
        if ($registeredVersion == PTSModule::VERSION) {
            return true;
        }

        $list = [];

        $upgradePath = _PS_MODULE_DIR_ . PTSModule::NAME . '/upgrades/';

        // Check if folder exist and it could be read
        if (file_exists($upgradePath) && ($files = scandir($upgradePath))) {
            // Read each file name
            foreach ($files as $file) {
                if (!in_array($file, ['.', '..', '.svn', 'index.php'])) {
                    $tab = explode('-', $file);
                    $fileVersion = basename($tab[1], '.php');

                    // Compare version, if minor than actual, we need to upgrade the module
                    if (count($tab) == 2 && version_compare($registeredVersion, $fileVersion) < 0) {
                        $list[] = [
                            'file' => $upgradePath . $file,
                            'version' => $fileVersion,
                            'upgrade_function' => 'upgrade_module_' . str_replace('.', '_', $fileVersion),
                        ];
                    }
                }
            }
        }

        usort($list, function ($a, $b) {
            return version_compare($a['version'], $b['version']);
        });

        $return = true;
        foreach ($list as $num => $fileDetail) {
            include $fileDetail['file'];

            // Call the upgrade function if defined
            if (function_exists($fileDetail['upgrade_function'])) {
                $return = $fileDetail['upgrade_function']($module);
                if ($return === true) {
                    $configurationService->set(PTSModule::PREFIX . '_VERSION', $fileDetail['version']);
                }
            }

            unset($list[$num]);
        }

        $configurationService->set(PTSModule::PREFIX . '_VERSION', PTSModule::VERSION);

        Tools::clearSmartyCache();
        Tools::clearCache();

        return $return;
    }

    public function isModuleValid()
    {
        return true;
    }
}
