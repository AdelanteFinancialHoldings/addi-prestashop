<?php
namespace Pts_Addi\Application\Core\Credential;

use Pts_Addi\Application\Core\AbstractService;

class CredentialService extends AbstractService
{
    public function __construct()
    {
        $this->init();
    }
}
