<?php
namespace Pts_Addi\Application\Core\Credential;

use Pts_Addi\Exception\CredentialException;
use Pts_Addi\PTSService;

class SaveCredential extends CredentialService
{
    private function validateRequireFields($allySlug, $clientId, $clientSecret)
    {
        if (empty($allySlug)) {
            throw new CredentialException(
                'Ally slug is required for the request',
                CredentialException::EMPTY_ALLY_SLUG
            );
        }

        if (empty($clientId) || empty($clientSecret)) {
            throw new CredentialException(
                'Client ID and Client Secret are required for the request',
                CredentialException::EMPTY_CLIENT_KEYS
            );
        }
    }

    public function save()
    {
        $enableSandbox = (bool) $this->getParameter('enableSandbox');
        $clientId = $this->getParameter('clientId');
        $clientSecret = $this->getParameter('clientSecret');
        $allySlug = $this->getParameter('allySlug');

        $this->validateRequireFields($allySlug, $clientId, $clientSecret);
        $this->configurationService->set('ADDI_ENABLE_SANDBOX', $enableSandbox);
        $this->configurationService->set('ADDI_CLIENT_ID', $clientId);
        $this->configurationService->set('ADDI_CLIENT_SECRET', $clientSecret);
        $this->configurationService->set('ADDI_ALLY_SLUG', $allySlug);

        $token = PTSService::get('pts_addi.core.api.create_token_service')->create();
        $this->configurationService->set('ADDI_TOKEN', json_encode($token));

        return true;
    }
}
