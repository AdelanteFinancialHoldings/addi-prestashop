<?php
namespace Pts_Addi\Application\Core\Order;

use Pts_Addi\Application\Core\AbstractService;

class OrderService extends AbstractService
{
    public function __construct()
    {
        $this->init();
    }
}
