<?php
namespace Pts_Addi\Application\Core\Order;

use Address;
use Cart;
use Country;
use Currency;
use Customer;
use DateTime;
use ImageType;
use Pts_Addi\Entity\AddiOrder;
use Pts_Addi\Exception\OrderException;
use Pts_Addi\PTSService;
use Tools;
use Validate;

class CreateOnApiService extends OrderService
{
    public function create()
    {
        $requestParameters = [
            'body' => $this->getBody(),
        ];

        return PTSService::get('pts_addi.core.api.create_order_service')
            ->setParameters($requestParameters)
            ->create();
    }

    private function getBody()
    {
        $cart = $this->getParameter('cart');

        if (!Validate::isLoadedObject($cart)) {
            throw new OrderException('The shopping cart didn\'t load correctly', OrderException::CART_DOESNT_EXISTS);
        }

        $customer = new Customer((int) $cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            throw new OrderException('The customer data didn\'t load correctly', OrderException::CUSTOMER_DOESNT_EXISTS);
        }

        $currency = new Currency((int) $cart->id_currency);
        if (!Validate::isLoadedObject($currency)) {
            throw new OrderException('The currency data didn\'t load correctly', OrderException::CURRENCY_DOESNT_EXISTS);
        }

        $billingAddress = new Address((int) $cart->id_address_invoice);
        if (!Validate::isLoadedObject($billingAddress)) {
            throw new OrderException('The billing address data didn\'t load correctly', OrderException::BILLING_ADDRESS_DOESNT_EXISTS);
        }

        $country = new Country((int) $billingAddress->id_country);
        if (!Validate::isLoadedObject($country)) {
            throw new OrderException('The country data didn\'t load correctly', OrderException::COUNTRY_DOESNT_EXISTS);
        }

        $totalAmount = $cart->getOrderTotal(true, Cart::BOTH);
        $shippingAmount = $cart->getOrderTotal(true, Cart::ONLY_SHIPPING);
        $totalTaxesAmount = $cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING) - $cart->getOrderTotal(false, Cart::BOTH_WITHOUT_SHIPPING);
        $date = new DateTime();

        $body = [
            'ecommercePlatform' => 'PRESTASHOP',
            'orderId' => AddiOrder::PREFIX_ID . $cart->id . '-' . $date->getTimestamp(),
            'totalAmount' => $this->formatNumber($totalAmount),
            'shippingAmount' => $this->formatNumber($shippingAmount),
            'totalTaxesAmount' => $this->formatNumber($totalTaxesAmount),
            'currency' => $currency->iso_code,
            'items' => $this->getItemList($cart),
            'client' => [
                'idType' => 'CC',
                'idNumber' => (int) substr($billingAddress->dni, 0, 14),
                'firstName' => $customer->firstname,
                'lastName' => $customer->lastname,
                'email' => $customer->email,
                'cellphone' => $billingAddress->phone_mobile,
                'cellphoneCountryCode' => '+' . $country->call_prefix,
                'address' => [
                    'lineOne' => $billingAddress->address1,
                    'city' => $billingAddress->city,
                    'country' => Country::getIsoById($billingAddress->id_country),
                ],
            ],
            'billingAddress' => [
                'lineOne' => $billingAddress->address1,
                'city' => $billingAddress->city,
                'country' => Country::getIsoById($billingAddress->id_country),
            ],
            'allyUrlRedirection' => [
                'logoUrl' => '',
                'callbackUrl' => $this->contextProvider->getLink()->getModuleLink($this->module->name, 'callback'),
                'redirectionUrl' => $this->contextProvider->getLink()->getModuleLink(
                    $this->module->name,
                    'redirect',
                    [
                        'cartId' => $cart->id,
                        'token' => Tools::encrypt($this->module->name . '/index'),
                    ]
                ),
            ],
        ];

        if ($cart->id_address_delivery == $cart->id_address_invoice) {
            $body['shippingAddress'] = [
                'lineOne' => $billingAddress->address1,
                'city' => $billingAddress->city,
                'country' => Country::getIsoById($billingAddress->id_country),
            ];
        } else {
            $shippingAddress = new Address((int) $cart->id_address_delivery);
            if (Validate::isLoadedObject($shippingAddress)) {
                $body['shippingAddress'] = [
                    'lineOne' => $shippingAddress->address1,
                    'city' => $shippingAddress->city,
                    'country' => Country::getIsoById($shippingAddress->id_country),
                ];
            }
        }

        return $body;
    }

    private function formatNumber($number)
    {
        return number_format($number, 2, '.', '');
    }

    private function getItemList($cart)
    {
        $itemList = [];

        foreach ($cart->getProducts() as $product) {
            $itemList[] = [
                'sku' => (string) $product['reference'] ?? $product['id_product'],
                'name' => $product['name'],
                'quantity' => (string) $product['quantity'],
                'unitPrice' => (string) Tools::ps_round($product['price'], 2),
                'tax' => (string) (Tools::ps_round($product['price_wt'], 2) - Tools::ps_round($product['price'], 2)),
                'pictureUrl' => $this->contextProvider->getLink()->getImageLink(
                    $product['link_rewrite'],
                    $product['id_image'],
                    ImageType::getFormattedName('home')
                ),
                'category' => $product['category'],
                'brand' => $product['manufacturer_name'],
            ];
        }

        return $itemList;
    }
}
