<?php
namespace Pts_Addi\Application\Core\Order;

use Pts_Addi\Entity\AddiOrder;
use Pts_Addi\Exception\OrderException;
use Pts_Addi\PTSService;

class SaveService extends OrderService
{
    private function validate()
    {
        if (empty($this->getParameter('orderId'))) {
            throw new OrderException('Unprocessable Content: Empty order id', OrderException::UNPROCESSABLE_CONTENT);
        }

        if (empty($this->getParameter('currencyId'))) {
            throw new OrderException('Unprocessable Content: Empty currency id', OrderException::UNPROCESSABLE_CONTENT);
        }

        if (empty($this->getParameter('status'))) {
            throw new OrderException('Unprocessable Content: Empty status', OrderException::UNPROCESSABLE_CONTENT);
        }
    }

    public function save()
    {
        $this->validate();

        $entityManager = PTSService::getEntityManager();
        $addiOrderRepository = $entityManager->getRepository(AddiOrder::class);
        
        // Buscar si ya existe un registro con este orderId
        $addiOrder = $addiOrderRepository->findOneBy(['idOrderAddi' => $this->getParameter('orderId')]);
        
        // Si no existe, crear uno nuevo
        if (!$addiOrder) {
            $addiOrder = new AddiOrder();
            $addiOrder->setIdOrderAddi($this->getParameter('orderId'));
            $addiOrder->setDateAdd();
        }

        // Actualizar los campos (tanto para nuevo como existente)
        $addiOrder->setIdApplication($this->getParameter('applicationId') ?? '');
        $addiOrder->setAmount($this->getParameter('amount'));
        $addiOrder->setIdCurrency($this->getParameter('currencyId'));
        $addiOrder->setStatus($this->getParameter('status'));

        $entityManager->persist($addiOrder);
        $entityManager->flush();

        return true;
    }
}
