<?php
namespace Pts_Addi\Application\Core\Translation;

use Pts_Addi\Application\Core\AbstractService;

class TranslationService extends AbstractService
{
    public function __construct()
    {
        $this->init();
    }

    public function getTranslationLocalPath()
    {
        return _PS_MODULE_DIR_ . $this->module::NAME . '/translations/';
    }
}
