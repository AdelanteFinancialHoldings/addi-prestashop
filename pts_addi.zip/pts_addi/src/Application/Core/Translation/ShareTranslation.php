<?php
namespace Pts_Addi\Application\Core\Translation;

use Mail;
use Pts_Addi\Exception\TranslationException;
use Tools;

class ShareTranslation extends TranslationService
{
    public function share()
    {
        $languageIsoCode = $this->getParameter('languageIsoCode');
        $fileName = $languageIsoCode . '.php';
        $filePath = realpath($this->getTranslationLocalPath() . $fileName);

        if (file_exists($filePath)) {
            $fileAttachment = [];
            $fileAttachment['content'] = Tools::file_get_contents($filePath);
            $fileAttachment['name'] = $languageIsoCode . '.php';
            $fileAttachment['mime'] = 'application/octet-stream';

            $translationList = $this->module->getBackTranslationList();
            $subjectMailTranslation = $translationList['subjectMailTranslation'];
            $subjectMail = $subjectMailTranslation . ' - PS:' . _PS_VERSION_ . ' - MOD:' . $this->module::VERSION;

            $send = Mail::Send(
                $this->configurationService->get('PS_LANG_DEFAULT'),
                'test',
                $subjectMail,
                [],
                'soporte@addi.com',
                null,
                null,
                null,
                $fileAttachment,
                null,
                _PS_MAIL_DIR_,
                null,
                $this->contextProvider->getShopId()
            );

            if ($send) {
                return true;
            } else {
                throw new TranslationException(
                    'An error has occurred to attempt send the translation',
                    TranslationException::ERROR_SENDING_MAIL
                );
            }
        } else {
            throw new TranslationException(
                'The file was not found at the specified path',
                TranslationException::FILE_NOT_FOUND
            );
        }
    }
}
