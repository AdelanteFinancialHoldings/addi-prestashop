<?php
namespace Pts_Addi\Application\Core\Translation;

use Pts_Addi\Exception\TranslationException;

class SaveTranslation extends TranslationService
{
    public function save()
    {
        $languageIsoCode = $this->getParameter('languageIsoCode');
        $translationList = $this->getParameter('translationList');
        $fileName = $languageIsoCode . '.php';

        if (!file_exists($this->getTranslationLocalPath() . $fileName)) {
            touch($this->getTranslationLocalPath() . $fileName);
        }

        $filePath = realpath($this->getTranslationLocalPath() . $fileName);
        if (is_writable($filePath)) {
            $line = '';

            $line .= '<?php' . "\n";
            $line .= 'global $_MODULE;' . "\n";
            $line .= '$_MODULE = array();' . "\n";

            foreach ($translationList as $key => $translation) {
                foreach ($translation as $translationMD5 => $translationItem) {
                    if (empty($translationItem['newValueLang'])) {
                        continue;
                    }

                    $line .= '$_MODULE[\'<{' . $this->module::NAME . '}prestashop>' . $key . '_';
                    $line .= trim($translationMD5) . '\']  = \'';
                    $line .= str_replace("'", "\'", trim($translationItem['newValueLang'])) . '\';' . "\n";
                }
            }

            if (!file_put_contents($filePath, $line)) {
                throw new TranslationException(
                    'An error has occurred while attempting to save the translations',
                    TranslationException::ERROR_SAVING
                );
            }

            $pathFileTemplate = dirname(__FILE__) . '/../../themes/' . _THEME_NAME_ . '/modules/' . $this->module::NAME . '/translations/' . $languageIsoCode . '.php';
            if (file_exists($pathFileTemplate)) {
                unlink($pathFileTemplate);
            }

            return true;
        } else {
            throw new TranslationException(
                'You do not have write permission in the translations file',
                TranslationException::ERROR_PERMISSION_FILE
            );
        }
    }
}
