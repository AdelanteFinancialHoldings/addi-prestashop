<?php
namespace Pts_Addi\Application\Core\Translation;

use Pts_Addi\Exception\TranslationException;
use Tools;

class ListTranslation extends TranslationService
{
    public function readFile($isoCode, $default = false)
    {
        $fileName = $isoCode . '.php';
        $filePath = realpath($this->getTranslationLocalPath() . $fileName);

        if (!file_exists($filePath)) {
            throw new TranslationException(
                'The file was not found at the specified path',
                TranslationException::FILE_NOT_FOUND
            );
        }

        $file = fopen($filePath, 'r');

        if (!$file) {
            throw new TranslationException(
                'Unable to open file',
                TranslationException::UNABLE_OPEN_FILE
            );
        }

        $translationList = [];

        while (!feof($file)) {
            $line = fgets($file);
            $lineExplode = explode('=', $line);
            $searchString = strpos($lineExplode[0], '<{' . $this->module::NAME . '}prestashop>');

            if (array_key_exists(1, $lineExplode) && $searchString) {
                $fileMD5 = str_replace(
                    '$' . "_MODULE['<{" . $this->module::NAME . '}prestashop>',
                    '',
                    $lineExplode[0]
                );
                $fileMD5 = str_replace("']", '', trim($fileMD5));

                $explodeFileMD5 = explode('_', $fileMD5);
                $md5 = array_pop($explodeFileMD5);
                $fileName = join('_', $explodeFileMD5);

                $labelTitle = $fileName;
                $valueLang = trim($lineExplode[1]);
                $valueLang = str_replace('\';', '', $valueLang);
                $valueLang = Tools::substr($valueLang, 1);

                $valueLang = str_replace("\'", "'", $valueLang);

                if ($default) {
                    $translationList[$labelTitle][$md5] = [
                        'valueLang' => $valueLang,
                    ];
                } else {
                    $translationList[$labelTitle][$md5] = $valueLang;
                }
            }
        }

        fclose($file);

        return $translationList;
    }

    public function list()
    {
        $isoCode = $this->getParameter('isoCode');
        if (empty($isoCode)) {
            $isoCode = $this->contextProvider->getLanguageIsoCode();
        }

        $translationList = $this->readFile('en', true);

        if (sizeof($translationList)) {
            $translationListSelected = $this->readFile($isoCode);

            foreach ($translationList as $keyPage => $translateEN) {
                foreach ($translateEN as $md5 => $label) {
                    if (!empty($md5) && !empty($keyPage)) {
                        $translationList[$keyPage][$md5]['newValueLang'] = '';

                        if (isset($translationListSelected[$keyPage][$md5])) {
                            $translationList[$keyPage][$md5]['newValueLang'] = $translationListSelected[$keyPage][$md5];
                        } elseif (!isset($translationList[$keyPage]['empty_elements'])) {
                            $translationList[$keyPage]['empty_elements'] = true;
                        }
                    }
                }
            }
        }

        return $translationList;
    }
}
