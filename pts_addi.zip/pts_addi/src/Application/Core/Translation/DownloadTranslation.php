<?php
namespace Pts_Addi\Application\Core\Translation;

class DownloadTranslation extends TranslationService
{
    public function downloadFile()
    {
        $languageIsoCode = $this->getParameter('languageIsoCode');

        $fileName = $languageIsoCode . '.php';
        $filePath = realpath($this->getTranslationLocalPath() . $fileName);

        if (file_exists($filePath)) {
            header('Content-Disposition: attachment; filename=' . $languageIsoCode . '.php');
            header('Content-Type: application/octet-stream');
            header('Content-Length: ' . filesize($filePath));
            readfile($filePath);
            exit;
        }
    }
}
