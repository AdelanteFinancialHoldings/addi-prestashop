<?php
namespace Pts_Addi\Application\Core\CodeEditor;

class ListCodeEditor extends CodeEditorService
{
    public function list()
    {
        $overrideCss = $this->configurationService->get($this->module::PREFIX . '_OVERRIDE_CSS');
        $overrideJs = $this->configurationService->get($this->module::PREFIX . '_OVERRIDE_JS');
        $overrideJs = html_entity_decode($overrideJs, ENT_QUOTES, 'UTF-8');

        return [
            'css' => [
                [
                    'fileIndex' => 'css_1',
                    'filePath' => realpath(_PS_MODULE_DIR_ . $this->module::NAME . '/views/css/front/override.css'),
                    'fileName' => 'override',
                    'content' => $overrideCss,
                ],
            ],
            'javascript' => [
                [
                    'fileIndex' => 'javascript_1',
                    'filePath' => realpath(_PS_MODULE_DIR_ . $this->module::NAME . '/views/js/front/override.js'),
                    'fileName' => 'override',
                    'content' => $overrideJs,
                ],
            ],
        ];
    }
}
