<?php
namespace Pts_Addi\Application\Core\CodeEditor;

use Pts_Addi\Application\Core\AbstractService;

class CodeEditorService extends AbstractService
{
    public function __construct()
    {
        $this->init();
    }
}
