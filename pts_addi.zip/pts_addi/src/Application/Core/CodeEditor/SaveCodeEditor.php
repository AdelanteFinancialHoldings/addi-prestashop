<?php
namespace Pts_Addi\Application\Core\CodeEditor;

use Pts_Addi\Exception\CodeEditorException;

class SaveCodeEditor extends CodeEditorService
{
    public function save()
    {
        $content = $this->getParameter('content');
        $filePath = urldecode($this->getParameter('filePath'));

        if (!file_exists($filePath)) {
            touch($filePath);
        }

        if (is_writable($filePath)) {
            $filetype = pathinfo($filePath);
            if ($filetype['extension'] === 'css') {
                $this->configurationService->set($this->module::PREFIX . '_OVERRIDE_CSS', $content);
            } elseif ($filetype['extension'] === 'js') {
                $this->configurationService->set($this->module::PREFIX . '_OVERRIDE_JS', $content);
            }

            $content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');

            if (file_put_contents($filePath, $content) === false) {
                throw new CodeEditorException('Failed to save changes', CodeEditorException::ERROR_SAVING);
            }

            return true;
        } else {
            throw new CodeEditorException('You do not have write permission in the translations file', CodeEditorException::ERROR_PERMISSION_FILE);
        }
    }
}
