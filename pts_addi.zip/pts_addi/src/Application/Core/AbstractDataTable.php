<?php
namespace Pts_Addi\Application\Core;

abstract class AbstractDataTable extends AbstractService
{
    private $identifier = 'id';
    private $limit = 20;

    public function __construct()
    {
        $this->init();
    }

    abstract public function getHeaderList();

    abstract public function processFilterData(array &$filterData);

    abstract public function getDataList(
        int $limit = null,
        int $offset = null,
        array $filters = [],
        bool $count = false
    );

    public function setIdentifier(string $identifier)
    {
        $this->identifier = $identifier;
    }

    public function getIdentifier()
    {
        return $this->identifier;
    }

    public function setLimit(int $limit)
    {
        $this->limit = $limit;
    }

    public function getLimit()
    {
        return $this->limit;
    }

    public function getActionList()
    {
        return [];
    }

    public function getFilterList(array $filterData = [])
    {
        return $filterData;
    }

    public function getRecordList(int $page, int $rows, array $filters)
    {
        $offset = ($page * $rows);

        $dataList = $this->getDataList($rows, $offset, $filters);

        foreach ($dataList as &$data) {
            $data['actionList'] = $this->getActionList();
        }

        return $dataList;
    }

    public function getTotalRecordList(array $filterData = [])
    {
        return (int) $this->getDataList(null, null, $filterData, true);
    }

    public function getStatusFieldList()
    {
        return [];
    }

    public function getMassiveActions()
    {
        return false;
    }

    public function list()
    {
        $paramList = $this->getParameterList();

        $rows = !empty($paramList['rows']) ? $paramList['rows'] : $this->getLimit();
        $page = !empty($paramList['page']) ? $paramList['page'] : 0;

        $filterData = [];
        $this->processFilterData($filterData);

        return [
            'identifier' => $this->getIdentifier(),
            'page' => $page,
            'rows' => $rows,
            'massiveActions' => $this->getMassiveActions(),
            'filters' => $this->getFilterList($filterData),
            'headers' => $this->getHeaderList(),
            'records' => $this->getRecordList($page, $rows, $filterData),
            'statusFields' => $this->getStatusFieldList(),
            'totalRecords' => $this->getTotalRecordList($filterData),
        ];
    }
}
