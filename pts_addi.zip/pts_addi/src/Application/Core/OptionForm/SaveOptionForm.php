<?php

namespace Pts_Addi\Application\Core\OptionForm;

use Pts_Addi\Exception\OptionFormException;
use Tools;

class SaveOptionForm extends OptionFormService
{
    public function save()
    {
        $data = $this->getParameterList();

        if (!is_array($data) || (is_array($data) && empty($data))) {
            throw new OptionFormException('The data cannot be sent empty.', OptionFormException::EMPTY_DATA);
        }

        $arrayConfigVarName = preg_split('/(?=[A-Z])/', $data['name']);
        $configVarName = implode('_', $arrayConfigVarName);
        $configVarName = Tools::strtoupper($configVarName);

        if (!$data['custom']) {
            $configVarName = $this->module::PREFIX . $configVarName;
        }

        $this->configurationService->set($configVarName, $data['value']);
    }
}
