<?php
namespace Pts_Addi\Application\Core\OptionForm;

use Pts_Addi\Application\Core\AbstractService;

class OptionFormService extends AbstractService
{
    public function __construct()
    {
        $this->init();
    }
}
