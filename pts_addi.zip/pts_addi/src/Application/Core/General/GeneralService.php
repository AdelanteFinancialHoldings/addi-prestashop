<?php
namespace Pts_Addi\Application\Core\General;

use Pts_Addi\Application\Core\AbstractService;

class GeneralService extends AbstractService
{
    public function __construct()
    {
        $this->init();
    }
}
