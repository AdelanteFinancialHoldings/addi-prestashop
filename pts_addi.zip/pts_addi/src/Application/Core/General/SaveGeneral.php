<?php
namespace Pts_Addi\Application\Core\General;

use Pts_Addi\Exception\GeneralException;

class SaveGeneral extends GeneralService
{
    private function validateRequireFields($callbackUser, $callbackPassword)
    {
        if (empty($callbackUser)) {
            throw new GeneralException(
                'Callback user is required for the request',
                GeneralException::EMPTY_CALLBACK_USER
            );
        }

        if (empty($callbackPassword)) {
            throw new GeneralException(
                'Callback password is required for the request',
                GeneralException::EMPTY_CALLBACK_PASSWORD
            );
        }
    }

    public function save()
    {
        $enableDebug = (bool) $this->getParameter('enableDebug');
        $ipDebug = $this->exitsParameter('ipDebug') ? $this->getParameter('ipDebug') : '';
        $callbackUser = $this->getParameter('callbackUser');
        $callbackPassword = $this->getParameter('callbackPassword');

        $this->validateRequireFields($callbackUser, $callbackPassword);
        $this->configurationService->set('ADDI_ENABLE_DEBUG', $enableDebug);
        $this->configurationService->set('ADDI_IP_DEBUG', $ipDebug);
        $this->configurationService->set('ADDI_CALLBACK_USER', $callbackUser);
        $this->configurationService->set('ADDI_CALLBACK_PASSWORD', $callbackPassword);

        return true;
    }
}
