<?php
namespace Pts_Addi\Application\Core;

use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;
use Tools;

abstract class AbstractService
{
    private $parameterList;
    protected $contextProvider;
    protected $configurationService;
    protected $module;

    public function init()
    {
        $this->contextProvider = PTSService::get('pts_addi.prestashop.provider.context');
        $this->configurationService = PTSService::get('pts_addi.prestashop.configuration');
        $this->module = PTSService::get('pts_addi.module');

        $this->contextProvider->getController()->php_self = $this->getPageName();
    }

    public function getPageName()
    {
        $pageName = $this->contextProvider->getController()->php_self;
        if (Tools::getIsset('pageName')) {
            $pageName = Tools::getValue('pageName');
        }

        return $pageName;
    }

    public function setParameters(array $parameterList)
    {
        $this->parameterList = $parameterList;

        return $this;
    }

    public function getParameterList()
    {
        if (is_array($this->parameterList)) {
            return $this->parameterList;
        }

        return [];
    }

    public function getParameter(string $name)
    {
        if (!array_key_exists($name, $this->getParameterList())) {
            throw new PTSException(
                sprintf('The parameter %s has not been sent.', $name),
                PTSException::PARAMETER_NOT_SENT
            );
        }

        return $this->getParameterList()[$name];
    }

    public function exitsParameter(string $name)
    {
        if (!array_key_exists($name, $this->getParameterList())) {
            return false;
        }

        return true;
    }
}
