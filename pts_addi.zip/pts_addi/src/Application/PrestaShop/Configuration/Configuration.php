<?php
namespace Pts_Addi\Application\PrestaShop\Configuration;

use Configuration as PrestaShopConfiguration;
use Pts_Addi\Application\PrestaShop\Provider\ShopProvider;
use Pts_Addi as PTSModule;
use Pts_Addi\Exception\PTSException;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

class Configuration
{
    private $optionsResolver;

    public function __construct(ShopProvider $shopProvider)
    {
        $shopId = $shopProvider->getContextShopID();
        $shopGroupId = $shopProvider->getContextShopGroupID();

        $this->optionsResolver = new OptionsResolver();
        $this->optionsResolver->setDefaults([
            'global' => false,
            'default_value' => '',
            'id_lang' => null,
            'is_lang' => false,
            'is_html' => false,
            'is_bool' => false,
        ]);
        $this->optionsResolver->setDefault('id_shop', function (Options $options) use ($shopId) {
            if (true === $options['global']) {
                return null;
            }

            return $shopId;
        });
        $this->optionsResolver->setDefault('id_shop_group', function (Options $options) use ($shopGroupId) {
            if (true === $options['global']) {
                return null;
            }

            return $shopGroupId;
        });

        $this->optionsResolver->setAllowedTypes('global', 'bool');
        $this->optionsResolver->setAllowedTypes('id_lang', ['null', 'int']);
        $this->optionsResolver->setAllowedTypes('id_shop', ['null', 'int']);
        $this->optionsResolver->setAllowedTypes('id_shop_group', ['null', 'int']);
        $this->optionsResolver->setAllowedTypes('is_lang', 'bool');
        $this->optionsResolver->setAllowedTypes('is_bool', 'bool');
        $this->optionsResolver->setAllowedTypes('is_bool', 'bool');
    }

    public function resolve(array $options)
    {
        return $this->optionsResolver->resolve($options);
    }

    public function has($key, array $options = [])
    {
        $settings = $this->resolve($options);

        return (bool) PrestaShopConfiguration::hasKey(
            $key,
            $settings['id_lang'],
            $settings['id_shop_group'],
            $settings['id_shop']
        );
    }

    public function get($key, array $options = [])
    {
        if (empty($options) && !empty(PTSModule::$moduleConfigList[$key])) {
            $options = PTSModule::$moduleConfigList[$key]['options'];
        }

        $settings = $this->resolve($options);
        if (PrestaShopConfiguration::isLangKey($key)) {
            $value = PrestaShopConfiguration::getConfigInMultipleLangs($key);
        } else {
            $value = PrestaShopConfiguration::get(
                $key,
                $settings['id_lang'],
                $settings['id_shop_group'],
                $settings['id_shop']
            );
        }

        if ($settings['is_bool']) {
            return (bool) $value;
        } else {
            return $value;
        }
    }

    public function set($key, $value, array $options = [])
    {
        $settings = $this->resolve($options);

        $success = (bool) PrestaShopConfiguration::updateValue(
            $key,
            $value,
            $settings['is_html'],
            $settings['id_shop_group'],
            $settings['id_shop']
        );

        if (false === $success) {
            throw new OPCException(sprintf('Could not set key %s in PrestaShop configuration', $key));
        }

        return $this;
    }

    public function setGlobal($key, $value, array $options = [])
    {
        $settings = $this->resolve($options);

        $success = (bool) PrestaShopConfiguration::updateValue(
            $key,
            $value,
            $settings['is_html'],
            0,
            0
        );

        if (false === $success) {
            throw new PTSException(sprintf('Could not set key %s in PrestaShop configuration', $key));
        }

        return $this;
    }

    public function remove($key)
    {
        $success = (bool) PrestaShopConfiguration::deleteByName($key);

        if (false === $success) {
            throw new PTSException(sprintf('Could not remove key %s from PrestaShop configuration', $key));
        }

        return $this;
    }
}
