<?php
namespace Pts_Addi\Application\PrestaShop\Provider;

use Configuration;
use Shop;
use Tools;

class ShopProvider
{
    private $prestashopContext;

    public function __construct(ContextProvider $prestashopContext)
    {
        $this->prestashopContext = $prestashopContext;
    }

    public function getIdentifier()
    {
        return (int) $this->prestashopContext->getShopId();
    }

    public function getGroupIdentifier()
    {
        return (int) $this->prestashopContext->getShopGroupId();
    }

    public function getShops()
    {
        return Shop::getShops();
    }

    public function getContextShopID()
    {
        return (int) Shop::getContextShopID(true);
    }

    public function getContextShopGroupID()
    {
        return (int) Shop::getContextShopGroupID(true);
    }

    public function getShopUrl($shopId)
    {
        return (new Shop($shopId))->getBaseURL();
    }

    public function isMultistoreActive()
    {
        return (bool) Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE');
    }

    public function getShopsUrl()
    {
        $shopList = Shop::getShops();
        $protocol = $this->getShopsProtocolInformations();
        $urlList = [];

        foreach ($shopList as $shop) {
            $urlList[] = [
                'id_shop' => $shop['id_shop'],
                'url' => $protocol['protocol'] . $shop[$protocol['domain_type']] . $shop['uri'],
            ];
        }

        return $urlList;
    }

    protected function getShopsProtocolInformations()
    {
        if (true === Tools::usingSecureMode()) {
            return [
                'domain_type' => 'domain_ssl',
                'protocol' => 'https://',
            ];
        }

        return [
            'domain_type' => 'domain',
            'protocol' => 'http://',
        ];
    }
}
