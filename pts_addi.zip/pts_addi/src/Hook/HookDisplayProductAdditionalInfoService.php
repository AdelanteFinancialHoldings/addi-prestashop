<?php

namespace Pts_Addi\Hook;

use Product;
use Pts_Addi;
use Pts_Addi\Application\PrestaShop\Configuration\Configuration;
use Pts_Addi\Application\PrestaShop\Provider\ContextProvider;
use Tools;

class HookDisplayProductAdditionalInfoService extends AbstractHook
{
    private $module;
    private $contextProvider;
    private $configurationService;

    public function __construct(Pts_Addi $module, ContextProvider $contextProvider, Configuration $configurationService)
    {
        $this->module = $module;
        $this->contextProvider = $contextProvider;
        $this->configurationService = $configurationService;
    }

    protected function executeRun()
    {
        $product = (object) $this->getParameters()['product'];
        $allySlug = $this->configurationService->get('ADDI_ALLY_SLUG');
        $widgetJsSrc = $this->configurationService->get('ADDI_WIDGET_JS_SRC');

        if (empty($product) || empty($allySlug) || empty($widgetJsSrc)) {
            return;
        }

        $price = Product::getPriceStatic($product->id);
        $decimals = _PS_PRICE_COMPUTE_PRECISION_ > 2 ? 2 : _PS_PRICE_COMPUTE_PRECISION_;

        if (version_compare(_PS_VERSION_, '1.7.7', '>=')) {
            $computingPrecision = $this->contextProvider->getContextLegacy()->getComputingPrecision();
            $decimals = $computingPrecision > 2 ? 2 : $computingPrecision;
        }

        $priceRounded = Tools::ps_round($price, $decimals);

        $smarty = $this->contextProvider->getSmarty();
        $smarty->assign([
            'price' => $priceRounded,
            'computingPrecision' => $decimals,
            'allySlug' => $allySlug,
            'widgetJsSrc' => $widgetJsSrc,
        ]);

        return $smarty->fetch(
            _PS_MODULE_DIR_ . $this->module->name . '/views/templates/hook/display_product_additional_info.tpl'
        );
    }
}
