<?php

namespace Pts_Addi\Hook;

use Address;
use Cart;
use Country;
use Media;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;
use PrestaShopLogger;
use Pts_Addi;
use Pts_Addi\Application\PrestaShop\Configuration\Configuration;
use Pts_Addi\Application\PrestaShop\Provider\ContextProvider;
use Pts_Addi\PTSService;
use Validate;

class HookPaymentOptionsService extends AbstractHook
{
    private $module;
    private $contextProvider;
    private $configurationService;

    public function __construct(Pts_Addi $module, ContextProvider $contextProvider, Configuration $configurationService)
    {
        $this->module = $module;
        $this->contextProvider = $contextProvider;
        $this->configurationService = $configurationService;
    }

    protected function executeRun()
    {
        $allySlug = $this->configurationService->get('ADDI_ALLY_SLUG');
        $widgetJsSrc = $this->configurationService->get('ADDI_WIDGET_JS_SRC');
        $token = $this->configurationService->get('ADDI_TOKEN');

        if (empty($allySlug) || empty($widgetJsSrc) || empty($token)) {
            return;
        }

        $allyConfig = PTSService::get('pts_addi.core.api.get_ally_config_service')->getAllyConfig();
        if (!$this->validate($allyConfig)) {
            return;
        }

        $newOption = new PaymentOption();
        $newOption->setModuleName($this->module->name)
            ->setCallToActionText($this->getPaymentDetail($allyConfig, 'name'))
            ->setAction($this->contextProvider->getLink()->getModuleLink($this->module->name, 'validation', [], true))
            ->setLogo($this->getPaymentDetail($allyConfig, 'logo'))
            ->setAdditionalInformation(
                $this->module->fetch(
                    'module:pts_addi/views/templates/hook/additional_information.tpl',
                    [
                        'allySlug' => $allySlug,
                        'widgetJsSrc' => $widgetJsSrc,
                    ]
                )
            );

        return [$newOption];
    }

    private function validate($allyConfig)
    {
        // Validar que la dirección de facturación sea de Colombia y que el cliente no sea una empresa
        $cart = $this->getParameter('cart');
        $billingAddress = new Address((int) $cart->id_address_invoice);
        if (!Validate::isLoadedObject($billingAddress)) {
            return false;
        }

        $countryIsoCode = Country::getIsoById($billingAddress->id_country);
        $allowedCountries = $this->module::ADDI_ALLOWED_COUNTRIES;
        if (!in_array($countryIsoCode, $allowedCountries) || !empty($billingAddress->company)) {
            return false;
        }

        // Validar que el monto de la compra sea igual o mayor al mínimo permitido para el aliado
        $totalAmount = $cart->getOrderTotal(true, Cart::BOTH);
        if (!property_exists($allyConfig, 'minAmount') || $totalAmount < $allyConfig->minAmount) {
            PrestaShopLogger::addLog(
                'Pts_Addi::HookPaymentOptionsService - Minimo de compra no valido para pagar con Addi. Valor: ' . $totalAmount,
                PrestaShopLogger::LOG_SEVERITY_LEVEL_INFORMATIVE,
                null,
                'Cart',
                $cart->id
            );

            return false;
        }

        // Valida que devuelva al menos una opcion de pago
        if (!property_exists($allyConfig, 'policies') || (property_exists($allyConfig, 'policies') && count($allyConfig->policies) === 0)) {
            PrestaShopLogger::addLog(
                'Pts_Addi::HookPaymentOptionsService - No se devolvio ninguna opcion de pago para el aliado. AllyConfig: ' . json_encode($allyConfig),
                PrestaShopLogger::LOG_SEVERITY_LEVEL_INFORMATIVE
            );

            return false;
        }

        return true;
    }

    private function getPaymentDetail($allyConfig, $detail)
    {
        $logoDir = _PS_MODULE_DIR_ . $this->module->name . '/views/img/';
        $productTypeList = array_column($allyConfig->policies, 'productType');

        $hasAddiPago = in_array('ADDI_PAGO', $productTypeList) && in_array('ADDI_FINANCIA', $productTypeList);
        $hasAddiPSE = in_array('ADDI_BNPN', $productTypeList);

        $paymentName = '';
        $paymentLogo = '';
        if ($hasAddiPago) {
            $paymentName = $this->module->l('Pay by credit', basename(__FILE__, '.php'));
            $paymentLogo = $logoDir . 'addi_logo.png';
        }

        if ($hasAddiPago && $hasAddiPSE) {
            $paymentName = $this->module->l('Pay by credit or debit with PSE', basename(__FILE__, '.php'));
            $paymentLogo = $logoDir . 'addi-pse-logo.png';
        }

        if ($hasAddiPSE && count($productTypeList) === 1) {
            $paymentName = $this->module->l('Debit with PSE', basename(__FILE__, '.php'));
            $paymentLogo = $logoDir . 'addi-pse-logo.png';
        }

        return $detail == 'name' ? $paymentName : Media::getMediaPath($paymentLogo);
    }
}
