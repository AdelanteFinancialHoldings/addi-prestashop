<?php
namespace Pts_Addi\Hook;

use Media;
use Pts_Addi;
use Tools;

class HookDisplayHeaderService extends AbstractHook
{
    private $module;

    protected $allowControllerList = [
        'product',
        'checkout',
    ];

    public function __construct(Pts_Addi $module)
    {
        $this->module = $module;
    }

    protected function executeRun()
    {
        $parameters = $this->getParameters();
        if (!isset($parameters['context'])) {
            return;
        }

        $context = $parameters['context'];
        $controller = $context->controller;

        Media::addJsDef($this->module->getFrontTemplateVarList());

        $controller->registerStylesheet(
            'module-pts_addi-checkout',
            'modules/pts_addi/views/css/front/front.css',
            [
                'media' => 'all',
                'priority' => 50,
            ]
        );

        $fileOverrideCss = Tools::file_get_contents('modules/pts_addi/views/css/front/override.css');
        if (!empty($fileOverrideCss)) {
            $controller->registerStylesheet(
                'module-pts_addi-override',
                'modules/pts_addi/views/css/front/override.css',
                [
                    'media' => 'all',
                    'priority' => 50,
                ]
            );
        }

        $controller->registerStylesheet(
            'module-pts_addi-compatibilities',
            'modules/pts_addi/views/css/front/compatibilities.css',
            [
                'media' => 'all',
                'priority' => 50,
            ]
        );

        $controller->registerJavascript(
            'module-pts_addi-compatibilities',
            'modules/pts_addi/views/js/front/compatibilities.js',
            [
                'priority' => 50,
                'attribute' => 'defer',
            ]
        );

        $controller->registerJavascript(
            'module-pts_addi-checkout',
            'modules/pts_addi/views/js/front/front.js',
            [
                'priority' => 50,
                'attribute' => 'defer',
            ]
        );

        $fileOverrideJs = Tools::file_get_contents('modules/pts_addi/views/js/front/override.js');
        if (!empty($fileOverrideJs)) {
            $controller->registerJavascript(
                'module-pts_addi-override',
                'modules/pts_addi/views/js/front/override.js',
                [
                    'priority' => 50,
                    'attribute' => 'defer',
                ]
            );
        }
    }
}
