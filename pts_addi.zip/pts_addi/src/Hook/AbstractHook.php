<?php
namespace Pts_Addi\Hook;

use Pts_Addi\Exception\PTSException;

abstract class AbstractHook
{
    private $parameterList;

    protected $allowControllerList = [];

    abstract protected function executeRun();

    public function run(array $parameterList = [])
    {
        if (!empty($this->allowControllerList)) {
            if (!isset($parameterList['context'])) {
                return;
            } else {
                $phpSelf = $parameterList['context']->controller->php_self;
                if (empty($phpSelf)) {
                    if (property_exists($parameterList['context']->controller, 'page_name')) {
                        $phpSelf = $parameterList['context']->controller->page_name;
                    } else {
                        $phpSelf = get_class($parameterList['context']->controller);
                        $phpSelf = str_replace('Controller', '', $phpSelf);
                    }
                }

                if (!in_array($phpSelf, $this->allowControllerList)) {
                    return;
                }
            }
        }

        $this->setParameters($parameterList);

        return $this->executeRun();
    }

    public function setParameters(array $parameterList)
    {
        $this->parameterList = $parameterList;

        return $this;
    }

    public function getParameters()
    {
        if (is_array($this->parameterList)) {
            return $this->parameterList;
        }

        return [];
    }

    public function getParameter(string $name)
    {
        if (!$this->exitsParameter($name)) {
            throw new PTSException(
                sprintf('The parameter %s has not been sent.', $name),
                PTSException::PARAMETER_NOT_SENT
            );
        }

        return $this->getParameters()[$name];
    }

    public function exitsParameter(string $name)
    {
        if (!array_key_exists($name, $this->getParameters())) {
            return false;
        }

        return true;
    }
}
