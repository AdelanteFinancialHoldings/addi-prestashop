<?php
namespace Pts_Addi\Entity;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Pts_Addi\Repository\OrderRepository")
 */
class AddiOrder
{
    public const PREFIX_ID = 'pts-cart-';

    /**
     * @var int
     *
     * @ORM\Id
     * @ORM\Column(name="id_order", type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="id_order_addi", type="string")
     */
    private $idOrderAddi;

    /**
     * @var string
     *
     * @ORM\Column(name="id_application", type="string")
     */
    private $idApplication;

    /**
     * @var float
     *
     * @ORM\Column(name="amount", type="decimal", precision=20, scale=6)
     */
    private $amount;

    /**
     * @var int
     *
     * @ORM\Column(name="id_currency", type="integer")
     */
    private $idCurrency;

    /**
     * @var int
     *
     * @ORM\Column(name="status", type="integer")
     */
    private $status;

    /**
     * @var date
     *
     * @ORM\Column(name="date_add", type="datetime")
     */
    private $dateAdd;

    public function getId()
    {
        return $this->id;
    }

    public function setIdOrderAddi($idOrderAddi)
    {
        $this->idOrderAddi = $idOrderAddi;
    }

    public function getIdOrderAddi()
    {
        return $this->idOrderAddi;
    }

    public function setIdApplication($idApplication)
    {
        $this->idApplication = $idApplication;
    }

    public function getIdApplication()
    {
        return $this->idApplication;
    }

    public function setAmount($amount)
    {
        $this->amount = (float) $amount;
    }

    public function getAmount()
    {
        return (float) $this->amount;
    }

    public function setIdCurrency($idCurrency)
    {
        $this->idCurrency = (int) $idCurrency;
    }

    public function getIdCurrency()
    {
        return (int) $this->idCurrency;
    }

    public function setStatus($status)
    {
        $this->status = (int) $status;
    }

    public function getStatus()
    {
        return (int) $this->status;
    }

    public function setDateAdd()
    {
        $this->dateAdd = new DateTime('NOW');
    }

    public function getDateAdd()
    {
        return $this->dateAdd;
    }

    public function toArray()
    {
        return [
            'idOrder' => $this->getId(),
            'idOrderAddi' => $this->getIdOrderAddi(),
            'idApplication' => $this->getIdApplication(),
            'amount' => $this->getAmount(),
            'idCurrency' => $this->getIdCurrency(),
            'status' => $this->getStatus(),
            'dateAdd' => $this->getDateAdd(),
        ];
    }

    public function toArrayLegacy()
    {
        return [
            'id_order' => $this->getId(),
            'id_order_addi' => $this->getIdOrderAddi(),
            'id_application' => $this->getIdApplication(),
            'amount' => $this->getAmount(),
            'id_currency' => $this->getIdCurrency(),
            'status' => $this->getStatus(),
            'date_add' => $this->getDateAdd(),
        ];
    }
}
