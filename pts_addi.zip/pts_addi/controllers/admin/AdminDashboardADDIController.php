<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;

class AdminDashboardADDIController extends ModuleAdminController
{
    protected $requestParameters;

    public function getRequestParameters()
    {
        return $this->requestParameters;
    }

    public function postProcess()
    {
        if (!Validate::isLoadedObject($this->context->employee) || !$this->context->employee->isLoggedBack()) {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>You do not have permission to make this request</h1>';
            exit;
        }

        $request = new Request();
        $this->requestParameters = $request->getContent();
        $this->requestParameters = json_decode($this->requestParameters, true);

        if ($this->requestParameters === null && !Tools::getIsset('action')) {
            Tools::redirectAdmin(
                Dispatcher::getInstance()->createUrl(
                    'AdminModules',
                    $this->context->language->id,
                    [
                        'token' => Tools::getAdminTokenLite('AdminModules'),
                        'configure' => $this->module->name,
                    ]
                )
            );
        } else {
            $coreService = PTSService::get('pts_addi.core.core_service');
            $coreService->executeActionRequest($this);
        }
    }
}
