<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;

require_once __DIR__ . '/AdminDashboardADDIController.php';

class AdminModuleADDIController extends AdminDashboardADDIController
{
    public function updateVersionAction()
    {
        try {
            $coreService = PTSService::get('pts_alegra.core.core_service');
            $return = $coreService->updateVersion($this->module);

            $response = [
                'success' => true,
                'message' => $return,
            ];

            if ($return === false) {
                $response['success'] = false;
                $response['message'] = $this->module->l('There is a problem updating the module, please contact the developers', basename(__FILE__, '.php'));
            }

            return $response;
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = $exception->getMessage();

        return $exception->getMessageFormatted($messageLang);
    }
}
