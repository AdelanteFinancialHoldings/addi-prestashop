<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;

require_once __DIR__ . '/AdminDashboardADDIController.php';

class AdminOptionFormADDIController extends AdminDashboardADDIController
{
    public function save()
    {
        try {
            $requestParameters = $this->getRequestParameters();

            PTSService::get('pts_addi.core.option_form.save_service')
                ->setParameters($requestParameters)
                ->save();

            return [
                'success' => true,
                'message' => $this->module->l('The configuration was saved successfully', basename(__FILE__, '.php')),
            ];
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\OptionFormException') {
            switch ($exception->getCode()) {
                case Pts_Addi\Exception\OptionFormException::EMPTY_DATA:
                    $messageLang = $this->module->l('The data cannot be sent empty.', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
