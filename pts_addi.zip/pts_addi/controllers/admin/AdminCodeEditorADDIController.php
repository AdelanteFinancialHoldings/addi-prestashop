<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Exception\CodeEditorException;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;

require_once __DIR__ . '/AdminDashboardADDIController.php';

class AdminCodeEditorADDIController extends AdminDashboardADDIController
{
    public function listAction()
    {
        return PTSService::get('pts_addi.core.code_editor.list_service')->list();
    }

    public function saveAction()
    {
        try {
            PTSService::get('pts_addi.core.code_editor.save_service')
                ->setParameters($this->requestParameters)
                ->save();

            return [
                'success' => true,
                'message' => $this->module->l('The code was successfully saved.', basename(__FILE__, '.php')),
            ];
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\CodeEditorException') {
            switch ($exception->getCode()) {
                case CodeEditorException::ERROR_PERMISSION_FILE:
                    $messageLang = $this->module->l('You do not have write permission in the translations file.', basename(__FILE__, '.php'));
                    break;
                case CodeEditorException::ERROR_SAVING:
                    $messageLang = $this->module->l('Failed to save changes.', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
