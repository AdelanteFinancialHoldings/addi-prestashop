<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Exception\GeneralException;
use Pts_Addi\Exception\PTSException;
use Pts_Addi\PTSService;

require_once __DIR__ . '/AdminDashboardADDIController.php';

class AdminGeneralADDIController extends AdminDashboardADDIController
{
    public function saveAction()
    {
        try {
            PTSService::get('pts_addi.core.general.save_service')
                ->setParameters($this->requestParameters)
                ->save();

            return [
                'success' => true,
                'message' => $this->module->l('The information was saved successfully', basename(__FILE__, '.php')),
            ];
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\GeneralException') {
            switch ($exception->getCode()) {
                case GeneralException::EMPTY_CALLBACK_USER:
                    $messageLang = $this->module->l('Callback user is required for the request', basename(__FILE__, '.php'));
                    break;
                case GeneralException::EMPTY_CALLBACK_PASSWORD:
                    $messageLang = $this->module->l('Callback password is required for the request', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
