<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Exception\PTSException;
use Pts_Addi\Exception\TranslationException;
use Pts_Addi\PTSService;

require_once __DIR__ . '/AdminDashboardADDIController.php';

class AdminTranslationADDIController extends AdminDashboardADDIController
{
    public function listAction()
    {
        try {
            return PTSService::get('pts_addi.core.translation.list_service')
                ->setParameters($this->requestParameters)
                ->list();
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function saveAction()
    {
        try {
            PTSService::get('pts_addi.core.translation.save_service')
                ->setParameters($this->requestParameters)
                ->save();

            return [
                'success' => true,
                'message' => $this->module->l('The translations have been successfully saved', basename(__FILE__, '.php')),
            ];
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function shareAction()
    {
        try {
            PTSService::get('pts_addi.core.translation.share_service')
                ->setParameters($this->requestParameters)
                ->share();

            return [
                'success' => true,
                'message' => $this->module->l('Your translation has been sent, we will consider it for future upgrades of the module', basename(__FILE__, '.php')),
            ];
        } catch (PTSException $exception) {
            return [
                'success' => false,
                'message' => $this->handleExceptionAjax($exception),
            ];
        }
    }

    public function downloadAction()
    {
        $this->requestParameters['languageIsoCode'] = Tools::getValue('languageIsoCode');

        return PTSService::get('pts_addi.core.translation.download_service')
            ->setParameters($this->requestParameters)
            ->downloadFile();
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = '';
        $exceptionClass = get_class($exception);

        if ($exceptionClass == 'Pts_Addi\Exception\TranslationException') {
            switch ($exception->getCode()) {
                case TranslationException::FILE_NOT_FOUND:
                    $messageLang = $this->module->l('The file was not found at the specified path', basename(__FILE__, '.php'));
                    break;
                case TranslationException::ERROR_PERMISSION_FILE:
                    $messageLang = $this->module->l('You do not have write permission in the translations file', basename(__FILE__, '.php'));
                    break;
                case TranslationException::UNABLE_OPEN_FILE:
                    $messageLang = $this->module->l('Unable to open file', basename(__FILE__, '.php'));
                    break;
                case TranslationException::ERROR_SAVING:
                    $messageLang = $this->module->l('An error has occurred while attempting to save the translations', basename(__FILE__, '.php'));
                    break;
                case TranslationException::ERROR_SENDING_MAIL:
                    $messageLang = $this->module->l('An error has occurred to attempt send the translation', basename(__FILE__, '.php'));
                    break;
                default:
                    break;
            }
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
