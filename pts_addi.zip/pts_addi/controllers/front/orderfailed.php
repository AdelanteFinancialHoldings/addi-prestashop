<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\PTSService;

class Pts_AddiOrderFailedModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $error = Tools::getValue('error');
        $ptsToken = Tools::getValue('ptsToken');

        if (!Module::isInstalled($this->module->name) ||
            !$ptsToken ||
            !PTSService::get('pts_addi.core.core_service')->isTokenValid($this->module->name, $ptsToken)
        ) {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Execution not allowed.</h1>';
            exit();
        }

        $this->context->smarty->assign([
            'error' => base64_decode($error),
            'urlContact' => $this->context->link->getPageLink('contact'),
            'urlOrder' => $this->context->link->getPageLink('order'),
        ]);

        $this->setTemplate('module:pts_addi/views/templates/front/orderfailed.tpl');
    }
}
