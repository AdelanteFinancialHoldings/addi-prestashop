<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Exception\ApiException;
use Pts_Addi\Exception\OrderException;
use Pts_Addi\PTSService;
use DateTime;

class Pts_AddiValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == $this->module->name) {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            exit($this->module->l('This payment method isn\'t available.'));
        }

        $customer = new Customer($cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        try {
            // Llamar a la API de Addi para crear la aplicación
            $redirectUrl = PTSService::get('pts_addi.core.order.create_on_api_service')
                ->setParameters(['cart' => $cart])
                ->create();

            // Si Addi responde exitosamente con la URL de redirección, crear la orden en PrestaShop
            if (!empty($redirectUrl)) {
                $orderStatusPending = Configuration::get('PTS_ADDI_PENDING');
                $totalAmount = $cart->getOrderTotal(true, Cart::BOTH);
                
                // Crear la orden en PrestaShop con estado pendiente
                $this->module->validateOrder(
                    (int) $cart->id,
                    $orderStatusPending,
                    $totalAmount,
                    $this->module->displayName,
                    null,
                    [],
                    (int) $cart->id_currency,
                    false,
                    $customer->secure_key
                );

                // Obtener la orden recién creada para guardar el ID de Addi
                $order = Order::getByCartId($cart->id);
                if (Validate::isLoadedObject($order)) {
                    // Generar el orderId de Addi basado en el ID real de la orden
                    $date = new DateTime();
                    $addiOrderId = 'pts-cart-' . $cart->id . '-' . $date->getTimestamp();
                    
                    // Guardar la relación en la tabla de Addi
                    PTSService::get('pts_addi.core.order.save_service')
                        ->setParameters([
                            'orderId' => $addiOrderId,
                            'applicationId' => '', // Se actualizará en el callback
                            'amount' => $totalAmount,
                            'currencyId' => (int) $cart->id_currency,
                            'status' => $orderStatusPending,
                        ])
                        ->save();
                }
            }

            Tools::redirect($redirectUrl);
        } catch (Exception $exception) {
            $exceptionMessage = $this->handleExceptionAjax($exception);
            $orderFailed = $this->context->link->getModuleLink(
                $this->module->name,
                'orderfailed',
                [
                    'error' => base64_encode($exceptionMessage),
                    'ptsToken' => PTSService::get('pts_addi.core.core_service')->getToken($this->module->name),
                ]
            );

            Tools::redirect($orderFailed);
        }
    }

    public function handleExceptionAjax($exception)
    {
        $messageLang = '';
        $exceptionClass = get_class($exception);

        switch ($exceptionClass) {
            case 'Pts_Addi\Exception\ApiException':
                switch ($exception->getCode()) {
                    case ApiException::TOKEN_ERROR:
                        $messageLang = $this->module->l('The token property has not been returned', basename(__FILE__, '.php'));
                        break;
                    case ApiException::BAD_REQUEST:
                        $messageLang = sprintf(
                            $this->module->l('HTTP %d: The request could not be understood or is asking for a resource that does not exist.', basename(__FILE__, '.php')),
                            ApiException::BAD_REQUEST
                        );
                        break;
                    case ApiException::UNAUTHORIZED:
                        $messageLang = sprintf(
                            $this->module->l('HTTP %d: Authentication credentials were missing or incorrect.', basename(__FILE__, '.php')),
                            ApiException::UNAUTHORIZED
                        );
                        break;
                    case ApiException::FORBIDDEN:
                        $messageLang = sprintf(
                            $this->module->l('HTTP %d: You do not have permission to access this resource.', basename(__FILE__, '.php')),
                            ApiException::FORBIDDEN
                        );
                        break;
                    case ApiException::NOT_FOUND:
                        $messageLang = sprintf(
                            $this->module->l('HTTP %d: The resource you are looking for could not be found.', basename(__FILE__, '.php')),
                            ApiException::NOT_FOUND
                        );
                        break;
                    default:
                        $messageLang = $exception->getMessage();
                        break;
                }
                // no break
            case 'Pts_Addi\Exception\OrderException':
                switch ($exception->getCode()) {
                    case OrderException::CART_DOESNT_EXISTS:
                        $messageLang = $this->module->l('The shopping cart didn\'t load correctly', basename(__FILE__, '.php'));
                        break;
                    case OrderException::CUSTOMER_DOESNT_EXISTS:
                        $messageLang = $this->module->l('The customer data didn\'t load correctly', basename(__FILE__, '.php'));
                        break;
                    case OrderException::CURRENCY_DOESNT_EXISTS:
                        $messageLang = $this->module->l('The currency data didn\'t load correctly', basename(__FILE__, '.php'));
                        break;
                    case OrderException::BILLING_ADDRESS_DOESNT_EXISTS:
                        $messageLang = $this->module->l('The billing address data didn\'t load correctly', basename(__FILE__, '.php'));
                        break;
                    case OrderException::COUNTRY_DOESNT_EXISTS:
                        $messageLang = $this->module->l('The country data didn\'t load correctly', basename(__FILE__, '.php'));
                        break;
                    default:
                        break;
                }
                // no break
            default:
                break;
        }

        return $exception->getMessageFormatted($messageLang);
    }
}
