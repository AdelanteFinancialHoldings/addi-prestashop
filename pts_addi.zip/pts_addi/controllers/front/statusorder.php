<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Entity\AddiOrder;
use Pts_Addi\PTSService;

class Pts_AddiStatusOrderModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $ptsToken = Tools::getValue('ptsToken');
        $cartId = Tools::getValue('cartId');

        if (!Module::isInstalled($this->module->name) ||
            !$ptsToken ||
            !PTSService::get('pts_addi.core.core_service')->isTokenValid($this->module->name, $ptsToken)
        ) {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Execution not allowed.</h1>';
            exit();
        }

        $addiOrderRepository = PTSService::getEntityManager()->getRepository(AddiOrder::class);
        $addiOrderEntity = $addiOrderRepository->getCurrentOrderByCartId($cartId);
        if (!$addiOrderEntity) {
            die('Cart not found.');
        }

        $addiOrderStatus = $addiOrderEntity->getStatus();

        $statusOrderPending = (int) Configuration::get('PTS_ADDI_PENDING');
        $statusOrderRejected = (int) Configuration::get('PTS_ADDI_REJECTED');
        $statusOrderAbandoned = (int) Configuration::get('PTS_ADDI_ABANDONED');
        $statusOrderDeclined = (int) Configuration::get('PTS_ADDI_DECLINED');
        $statusOrderInternalError = (int) Configuration::get('PTS_ADDI_INTERNAL_ERROR');

        $statusTitles = [
            $statusOrderPending => [
                'title' => $this->module->l('Pending Approval', basename(__FILE__, '.php')),
                'text' => $this->module->l('Your order is currently pending approval from Addi. Please be patient as we await confirmation to proceed.', basename(__FILE__, '.php')),
            ],
            $statusOrderRejected => [
                'title' => $this->module->l('Order Rejected', basename(__FILE__, '.php')),
                'text' => $this->module->l('Unfortunately, your order has been rejected by Addi. You have not been approved for credit.', basename(__FILE__, '.php')),
            ],
            $statusOrderAbandoned => [
                'title' => $this->module->l('Order Abandoned', basename(__FILE__, '.php')),
                'text' => $this->module->l('Regrettably, your order has been abandoned as it exceeded the maximum time limit for processing on the Addi platform.', basename(__FILE__, '.php')),
            ],
            $statusOrderDeclined => [
                'title' => $this->module->l('Order Declined', basename(__FILE__, '.php')),
                'text' => $this->module->l('Unfortunately, you have declined the credit application through Addi. You can try again at another time if you wish.', basename(__FILE__, '.php')),
            ],
            $statusOrderInternalError => [
                'title' => $this->module->l('Internal Error', basename(__FILE__, '.php')),
                'text' => $this->module->l('Sorry, an internal error has occurred on the Addi platform. Please choose an alternative payment method.', basename(__FILE__, '.php')),
            ],
        ];

        $contextProvider = PTSService::get('pts_addi.prestashop.provider.context');
        $contextProvider->getSmarty()->assign([
            'cartId' => $cartId,
            'orderStatusTitle' => $statusTitles[$addiOrderStatus]['title'],
            'orderStatusText' => $statusTitles[$addiOrderStatus]['text'],
            'addiOrderStatus' => $addiOrderStatus,
            'statusOrderPending' => $statusOrderPending,
            'urlContact' => $contextProvider->getLink()->getPageLink('contact'),
            'urlOrder' => $contextProvider->getLink()->getPageLink('order'),
        ]);

        $this->setTemplate('module:pts_addi/views/templates/front/statusorder.tpl');
    }
}
