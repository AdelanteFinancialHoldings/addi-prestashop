<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\PTSService;

class Pts_AddiCallbackModuleFrontController extends ModuleFrontController
{
    private const REQUIRED_FIELDS = ['orderId', 'applicationId', 'currency', 'status'];

    public function run()
    {
        $this->init();

        header('Content-type: application/json');
        header('Accept: application/json');

        try {
            $this->validateConfigAndCredentials($serverAuthUser, $serverAuthPwd);

            $rawPost = Tools::file_get_contents('php://input');
            if (empty($rawPost)) {
                $error = json_encode([
                    'code' => 400,
                    'message' => 'Invalid JSON provided: No data received',
                ]);

                throw new Exception($error, 400);
            }

            $callbackResponse = json_decode($rawPost);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $error = json_encode([
                    'code' => 400,
                    'message' => 'Invalid JSON provided: ' . json_last_error_msg(),
                ]);

                throw new Exception($error, 400);
            }

            foreach (self::REQUIRED_FIELDS as $field) {
                if (
                    !property_exists($callbackResponse, $field) ||
                    (property_exists($callbackResponse, $field) && empty($callbackResponse->$field))
                ) {
                    $error = json_encode([
                        'code' => 422,
                        'message' => "Missing required parameter: $field",
                    ]);

                    throw new Exception($error, 422);
                }
            }

            PrestaShopLogger::addLog(
                'Pts_Addi::CallbackModuleFrontController - Callback received ' . $rawPost,
                1
            );

            $this->processCallback($callbackResponse);

            header('Authorization: Basic ' . base64_encode("$serverAuthUser':'$serverAuthPwd"));
            header('HTTP/2 200 OK');
            echo $rawPost;
            exit;
        } catch (Exception $exception) {
            PrestaShopLogger::addLog(
                'Pts_Addi::CallbackModuleFrontController - Error Callback not received: ' . $exception->getMessage(),
                3
            );

            $code = $exception->getCode();
            $message = $exception->getMessage();

            header("HTTP/2 $code");
            echo $message;
            exit;
        }
    }

    private function validateConfigAndCredentials(&$serverAuthUser, &$serverAuthPwd)
    {
        $serverData = $_SERVER;

        if ((isset($serverData['REQUEST_METHOD']) && $serverData['REQUEST_METHOD'] === 'GET') ||
            (isset($serverData['HTTP_ACCEPT']) && strpos($serverData['HTTP_ACCEPT'], 'text/html') !== false) ||
            (isset($serverData['HTTP_USER_AGENT']) && preg_match('/(mozilla|chrome|safari|opera|msie)/i', $serverData['HTTP_USER_AGENT']))
        ) {
            throw new Exception('Not Found', 404);
        }

        if (isset($serverData['CONTENT_TYPE']) && strpos($serverData['CONTENT_TYPE'], 'application/json') === false) {
            $error = json_encode([
                'code' => 400,
                'message' => 'Invalid content type',
            ]);

            throw new Exception($error, 400);
        }

        if (isset($serverData['PHP_AUTH_USER'], $serverData['PHP_AUTH_PW'])) {
            $serverAuthUser = $serverData['PHP_AUTH_USER'];
            $serverAuthPwd = $serverData['PHP_AUTH_PW'];
        } elseif (isset($serverData['HTTP_AUTHORIZATION'])) {
            if (strpos(strtolower($serverData['HTTP_AUTHORIZATION']), 'basic') === 0) {
                list($serverAuthUser, $serverAuthPwd) = explode(':', base64_decode(substr($serverData['HTTP_AUTHORIZATION'], 6)));
            }
        } elseif (isset($serverData['REDIRECT_HTTP_AUTHORIZATION'])) {
            if (strpos(strtolower($serverData['REDIRECT_HTTP_AUTHORIZATION']), 'basic') === 0) {
                list($serverAuthUser, $serverAuthPwd) = explode(':', base64_decode(substr($serverData['REDIRECT_HTTP_AUTHORIZATION'], 6)));
            }
        } else {
            $error = json_encode([
                'code' => 401,
                'message' => 'Authentication credentials were not provided on server',
            ]);

            throw new Exception($error, 401);
        }

        $callBackUser = Configuration::get('ADDI_CALLBACK_USER');
        $callBackPassword = Configuration::get('ADDI_CALLBACK_PASSWORD');

        if (($serverAuthUser != $callBackUser) || ($serverAuthPwd != $callBackPassword)) {
            $error = json_encode([
                'code' => 401,
                'message' => 'Invalid username or password',
            ]);

            throw new Exception($error, 401);
        }
    }

    private function processCallback($callbackResponse)
    {
        preg_match('/pts-cart-(\d+)-\d+/', $callbackResponse->orderId, $cart);
        $cartId = (int) $cart[1];

        $orderStatusApproved = Configuration::get('PTS_ADDI_APPROVED');
        $orderStatusInternalError = Configuration::get('PTS_ADDI_INTERNAL_ERROR');

        $callBackOrderId = $callbackResponse->orderId;
        $callBackApplicationId = $callbackResponse->applicationId;
        $callBackAmount = (float) $callbackResponse->approvedAmount;
        $callBackCurrencyId = (int) Currency::getIdByIsoCode($callbackResponse->currency);
        $callBackStatus = (int) Configuration::get("PTS_ADDI_$callbackResponse->status");

        $order = Order::getByCartId($cartId);
        
        // La orden debe existir previamente (creada en validation.php)
        if (!Validate::isLoadedObject($order)) {
            $error = json_encode([
                'code' => 404,
                'message' => 'Order not found for cart ID: ' . $cartId,
            ]);
            
            PrestaShopLogger::addLog(
                'Pts_Addi::CallbackModuleFrontController - Order not found for callback: ' . $callBackOrderId,
                3
            );
            
            throw new Exception($error, 404);
        }

        // Actualizar el estado de la orden existente
        if ($order->current_state !== $callBackStatus) {
            $order->setCurrentState($callBackStatus);
            
            PrestaShopLogger::addLog(
                'Pts_Addi::CallbackModuleFrontController - Order state updated: ' . $callBackOrderId . 
                ' from ' . $order->current_state . ' to ' . $callBackStatus,
                1
            );
        }

        // Verificar y actualizar el monto solo para estados aprobados
        // Para estados rechazados/declinados, Addi siempre envía approvedAmount = 0
        
        if ($callBackStatus == $orderStatusApproved) {
            // Solo validar monto para órdenes aprobadas
            $orderOriginalAmount = (float) $order->total_paid_tax_incl;
            
            if ($orderOriginalAmount !== $callBackAmount) {
                PrestaShopLogger::addLog(
                    'Pts_Addi::CallbackModuleFrontController - Amount difference detected for approved order: ' . $callBackOrderId .
                    ' PrestaShop original total: ' . $orderOriginalAmount .
                    ' Addi approved amount: ' . $callBackAmount,
                    2
                );

                // Si hay diferencia significativa, marcar como error interno
                if (abs($orderOriginalAmount - $callBackAmount) > 1) {
                    $order->setCurrentState($orderStatusInternalError);
                }
            }
            
            // Actualizar el monto pagado real solo para órdenes aprobadas
            $order->total_paid_real = $callBackAmount;
        } else {
            // Para estados no aprobados, el monto pagado real debe ser 0
            $order->total_paid_real = 0;
        }

        // Actualizar la transacción ID con el applicationId de Addi
        if (!empty($callBackApplicationId)) {
            $payments = $order->getOrderPayments();
            if (!empty($payments)) {
                $payment = $payments[0];
                $payment->transaction_id = $callBackApplicationId;
                $payment->update();
            }
        }

        if (!$order->update()) {
            $error = json_encode([
                'code' => 500,
                'message' => 'Error updating order',
            ]);

            throw new Exception($error, 500);
        }

        $parameterList = [
            'orderId' => $callBackOrderId,
            'applicationId' => $callBackApplicationId,
            'amount' => $callBackAmount,
            'currencyId' => $callBackCurrencyId,
            'status' => $callBackStatus,
        ];

        return PTSService::get('pts_addi.core.order.save_service')
            ->setParameters($parameterList)
            ->save();
    }
}
