<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use Pts_Addi\Entity\AddiOrder;
use Pts_Addi\PTSService;
use Symfony\Component\HttpFoundation\Request;

class Pts_AddiRedirectModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        $request = Request::createFromGlobals();
        $cartId = $request->query->get('cartId');

        $addiOrderRepository = PTSService::getEntityManager()->getRepository(AddiOrder::class);
        $addiOrderEntity = $addiOrderRepository->getCurrentOrderByCartId($cartId);

        if ($addiOrderEntity) {
            $cart = new Cart($cartId);
            $customer = new Customer($cart->id_customer);
            $order = Order::getByCartId($cartId);

            // La orden ya debe existir (creada en validation.php)
            // Solo redirigir según el estado actual
            if ($addiOrderEntity->getStatus() == Configuration::get('PTS_ADDI_APPROVED')) {
                $pageLink = $this->context->link->getPageLink(
                    'order-confirmation',
                    null,
                    (int) $cart->id_lang,
                    [
                        'id_cart' => (int) $cartId,
                        'id_module' => (int) $this->module->id,
                        'key' => $customer->secure_key,
                    ]
                );
            } else {
                $pageLink = $this->context->link->getModuleLink(
                    $this->module->name,
                    'statusorder',
                    [
                        'cartId' => (int) $cartId,
                        'ptsToken' => PTSService::get('pts_addi.core.core_service')->getToken($this->module->name),
                    ]
                );
            }
        } else {
            $pageLink = $this->context->link->getPageLink('order');
        }

        Tools::redirect($pageLink);
    }
}
